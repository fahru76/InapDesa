# InapDesa — direct homestay booking with advance payments

A booking site for private homestay owners and boutique hosts. Guests pick dates on a live price calendar, pay a deposit (or the full amount) through Stripe, and get a QR check-in pass. Hosts manage availability, payments, check-ins and WhatsApp/SMS guest messages from a dashboard.

**Stack:** Next.js 16 (App Router, Turbopack) · React 19 · TypeScript · Tailwind CSS v4 · Framer Motion · Lucide · Supabase (Postgres + RLS + Auth + Storage) · Stripe Payment Element + Express Checkout (cards, Apple Pay, Google Pay, FPX/GrabPay when enabled).

---

## 1. Prerequisites

| Tool | Version | Check |
|---|---|---|
| Node.js | 20.9+ (22 LTS recommended) | `node -v` |
| npm | 10+ | `npm -v` |
| Supabase project | — | dashboard.supabase.com |
| Stripe account | test mode is fine | dashboard.stripe.com |
| Stripe CLI (optional, local webhooks) | latest | `stripe -v` |

## 2. Install

Run in the project folder (e.g. `C:\InapDesa` in PowerShell, or a terminal in VS Code):

```bash
npm install
```

## 3. Environment variables

`.env.local` (git-ignored) already contains your Supabase URL and publishable key. Fill in the rest yourself — **never paste secret keys into chats, tickets or commits**.

| Variable | Where to find it |
|---|---|
| `NEXT_PUBLIC_SITE_URL` | `http://localhost:3000` locally; your domain in production |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Supabase → API Keys → Publishable key |
| `SUPABASE_SECRET_KEY` | Supabase → API Keys → Secret key (**server only**) |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe → Developers → API keys (`pk_test_…`) |
| `STRIPE_SECRET_KEY` | Stripe → Developers → API keys (`sk_test_…`) |
| `STRIPE_WEBHOOK_SECRET` | `stripe listen` output (local) or the webhook endpoint's signing secret (prod) |
| `BOOKING_HOLD_MINUTES` | Minutes unpaid checkouts hold dates (default 15) |
| `HOST_EMAIL_ALLOWLIST` | Comma-separated emails allowed into `/host` (recommended in production) |

`.env.example` documents the same variables for new environments.

## 4. Database

Migrations live in `supabase/migrations/`:

| File | What it does |
|---|---|
| `20261003000000_inapdesa_init.sql` | Enums, tables (`profiles`, `properties`, `property_images`, `blocked_dates`, `bookings`, `transactions`), double-booking exclusion constraint, RPCs, RLS policies, `property-images` storage bucket |
| `20261003000100_harden_function_exposure.sql` | Moves RLS helper functions to a non-exposed `private` schema; revokes direct execution of the signup trigger |
| `supabase/seed.sql` | Demo listing "Teratak Senja" + 3 blocked nights |

> **Status for project `ctbphzkqmyhdcsahlqio`:** both migrations and the seed have already been applied (2026‑10‑03). Skip to step 5.

For a new project, either:

```bash
# Option A — Supabase CLI
npx supabase link --project-ref <your-ref>
npx supabase db push
psql "<connection string>" -f supabase/seed.sql   # optional demo data
```

or paste each file, in order, into **Supabase → SQL Editor** and run it.

To regenerate TypeScript types after schema changes:

```bash
npx supabase gen types typescript --project-id <your-ref> --schema public > src/lib/database.types.ts
```

## 5. Auth (host sign-in)

1. Supabase → **Authentication → URL Configuration**:
   - Site URL: `http://localhost:3000` (your domain in production)
   - Redirect URLs: add `http://localhost:3000/auth/callback` and `https://<your-domain>/auth/callback`
2. Sign in at `/login` with your email (magic link).
3. **Claim the demo property** so it appears in your dashboard (SQL Editor):

   ```sql
   update public.properties
      set host_id = (select id from auth.users where email = 'you@example.com')
    where slug = 'teratak-senja';
   ```

   Or create a new listing from **Host → Settings**.
4. Production: set `HOST_EMAIL_ALLOWLIST` and consider disabling open sign-ups (Authentication → Providers → Email → *Allow new users to sign up* off, after creating your account).

## 6. Stripe

1. Use **test mode** keys while developing.
2. Payment methods: Stripe Dashboard → Settings → Payment methods. Enable Cards, Apple Pay, Google Pay, and for MYR: **FPX** and **GrabPay**. The Payment Element shows whatever is enabled and eligible for the currency.
3. Apple Pay on your production domain: Settings → Payment method domains → add your domain.
4. Local webhooks:

   ```bash
   stripe login
   npm run stripe:listen        # = stripe listen --forward-to localhost:3000/api/stripe/webhook
   ```

   Copy the printed `whsec_…` into `STRIPE_WEBHOOK_SECRET` and restart `npm run dev`.
5. Production webhook: Developers → Webhooks → Add endpoint `https://<your-domain>/api/stripe/webhook` with events:
   `payment_intent.succeeded`, `payment_intent.payment_failed`, `payment_intent.canceled`, `charge.refunded`.

Test card: `4242 4242 4242 4242`, any future date, any CVC.

## 7. Run

```bash
npm run dev        # http://localhost:3000
npm test           # pricing & date unit tests (vitest)
npm run typecheck
npm run build && npm start
```

---

## How it works

### Booking flow

1. **Listing** (`/stays/[slug]`): gallery + lightbox, amenities, host card, live availability calendar with nightly weekday/weekend prices. Desktop: sticky booking card. Mobile: bottom bar → drag-to-dismiss bottom sheet.
2. **Checkout** (`/stays/[slug]/checkout`): server re-validates dates and capacity → guest details → `POST /api/bookings`.
3. **Hold** — the server recomputes the price from the database (client prices are never trusted), inserts a `pending_payment` booking with `hold_expires_at`, and creates a Stripe PaymentIntent for the **amount due today**. A Postgres exclusion constraint makes double-booking impossible, even under concurrent checkouts.
4. **Payment** — Stripe Payment Element / Express Checkout. On success the guest returns to `/booking/[id]?token=…`.
5. **Confirmation** — the webhook (or a direct Stripe check from the receipt page if the webhook is late) calls `finalize_booking_payment`, which is idempotent. If a hold lapsed and the dates were taken in the meantime, the booking is cancelled and the payment **refunded automatically**.
6. **Receipt** — QR check-in pass (encodes `/host/check-in/<reference>`), add-to-calendar (.ics), print, WhatsApp the host.

### Advance payment policy (per property, Host → Settings)

| Policy | Due today | Due at check-in |
|---|---|---|
| `deposit` (10–100%) | `round(pct × (nights + cleaning))` | remaining stay charges + refundable security deposit |
| `full` | everything incl. security deposit | 0 |

All money is stored as integer minor units (sen). Weekend nights are configurable (default Fri & Sat nights).

### Host dashboard (`/host`)

- **Overview:** advance payments this month (net of refunds), balance to collect, arrivals, 30-day occupancy, Stripe pending/available balance and upcoming payouts, recent transactions.
- **Calendar:** tap-to-select date ranges → close/open nights.
- **Bookings:** filters, guest contact, one-tap **WhatsApp / SMS** with templates (confirmation, arrival details, balance reminder, thank-you), cancel with optional Stripe refund.
- **Check-in:** scan the guest's QR → record on-site balance → checked in.
- **Settings:** listing details, rates, policy (with live deposit preview), amenities, house rules, host profile, photo upload (Supabase Storage).

### Security model

- RLS on every table. Anonymous users can read published listings and images, and availability via `get_unavailable_dates` (dates only, no guest data).
- Bookings/transactions are readable only by the property's host. All writes go through the server (secret key) or `SECURITY DEFINER` RPCs that check ownership.
- Guest receipts require an unguessable `access_token` (UUID) in the URL.
- Stripe webhooks are signature-verified; all handlers are idempotent.
- RLS helper functions live in a non-exposed `private` schema.

## Project structure

```
src/
  app/
    page.tsx                         Home (listings)
    stays/[slug]/page.tsx            Listing + booking
    stays/[slug]/checkout/page.tsx   Checkout
    booking/[id]/page.tsx            Receipt / QR pass
    api/bookings/route.ts            Create hold + PaymentIntent
    api/stripe/webhook/route.ts      Stripe webhook
    login/, auth/callback, auth/signout
    host/                            Dashboard (overview, calendar, bookings, check-in, settings, actions.ts)
  components/
    booking/   calendar, guest selector, price breakdown, panel, mobile sheet
    checkout/  Stripe checkout flow
    property/  gallery + lightbox, amenities, host card
    receipt/   QR pass, poller, actions
    host/      nav, availability manager, booking actions, forms, photo manager
    ui/        button, field, bottom sheet, status badge
  lib/         pricing, dates, validation, messaging, Supabase/Stripe clients, booking service
  proxy.ts     Session refresh + /host guard (Next.js 16 "proxy", formerly middleware)
supabase/
  migrations/  SQL migrations
  seed.sql     Demo data
```

## Deploying (Vercel)

1. Push to GitHub → import in Vercel.
2. Add all environment variables (Production + Preview). Set `NEXT_PUBLIC_SITE_URL` to the production URL.
3. Add the production Stripe webhook (step 6.5) and Supabase redirect URL (step 5.1).
4. Switch to Stripe live keys when ready.

## Notes & limitations

- Stripe sends receipt emails automatically only in live mode (and only if enabled in Stripe settings). No transactional email service is bundled; guest messaging is via WhatsApp/SMS deep links.
- Expired holds are released whenever a new booking is attempted. For tidy data you can also schedule `select public.release_expired_holds();` with Supabase Cron.
- Payouts in the dashboard read the Stripe account the secret key belongs to (single-host setup). Multi-host marketplaces would need Stripe Connect.
