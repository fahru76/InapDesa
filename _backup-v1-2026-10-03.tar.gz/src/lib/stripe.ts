import "server-only";

import Stripe from "stripe";
import { serverEnv } from "@/lib/env";

let stripeClient: Stripe | undefined;

/** Server-side Stripe client. API version is pinned by the installed SDK release. */
export function getStripe(): Stripe {
  stripeClient ??= new Stripe(serverEnv.stripeSecretKey, {
    appInfo: { name: "InapDesa", version: "1.0.0" },
    maxNetworkRetries: 2,
  });
  return stripeClient;
}

export type { Stripe };
