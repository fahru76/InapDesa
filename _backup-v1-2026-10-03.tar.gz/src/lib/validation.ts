import { z } from "zod";
import { isISODate } from "./dates";
import { normalizePhone } from "./utils";

const isoDate = z.string().refine(isISODate, "Use YYYY-MM-DD");
const phone = z
  .string()
  .trim()
  .min(6, "Enter a phone number")
  .transform((v, ctx) => {
    const e164 = normalizePhone(v);
    if (!e164) {
      ctx.addIssue({ code: "custom", message: "Enter a valid phone number with country code" });
      return z.NEVER;
    }
    return e164;
  });

export const guestDetailsSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name").max(120),
  email: z.email("Enter a valid email").max(200),
  phone,
  specialRequests: z.string().trim().max(1000).optional().default(""),
});

export const createBookingSchema = z.object({
  propertyId: z.uuid(),
  checkIn: isoDate,
  checkOut: isoDate,
  adults: z.number().int().min(1).max(50),
  children: z.number().int().min(0).max(50),
  infants: z.number().int().min(0).max(10),
  guest: guestDetailsSchema,
});

export type CreateBookingInput = z.infer<typeof createBookingSchema>;
export type GuestDetailsInput = z.input<typeof guestDetailsSchema>;

// ─── Host property settings (FormData) ─────────────────────────────────────

const money = z.coerce.number().min(0, "Must be 0 or more").max(1_000_000);
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === "" ? null : v));

export const SUPPORTED_CURRENCIES = ["MYR", "SGD", "IDR", "THB", "USD"] as const;

export const propertySettingsSchema = z
  .object({
    slug: z
      .string()
      .trim()
      .toLowerCase()
      .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Lowercase letters, numbers and dashes only")
      .min(3)
      .max(60),
    title: z.string().trim().min(3).max(120),
    tagline: optionalText(160),
    description: z.string().trim().max(5000),
    address_line: optionalText(200),
    city: z.string().trim().min(2).max(80),
    region: optionalText(80),
    country: z.string().trim().min(2).max(80),
    bedrooms: z.coerce.number().int().min(0).max(30),
    beds: z.coerce.number().int().min(0).max(60),
    bathrooms: z.coerce.number().min(0).max(30),
    max_guests: z.coerce.number().int().min(1).max(50),
    max_infants: z.coerce.number().int().min(0).max(10),
    check_in_time: z.string().regex(/^\d{2}:\d{2}$/),
    check_out_time: z.string().regex(/^\d{2}:\d{2}$/),
    currency: z.enum(SUPPORTED_CURRENCIES),
    weekday_rate: money.refine((v) => v > 0, "Rate must be above 0"),
    weekend_rate: money.refine((v) => v > 0, "Rate must be above 0"),
    weekend_days: z.array(z.coerce.number().int().min(1).max(7)).max(7),
    cleaning_fee: money,
    security_deposit: money,
    min_nights: z.coerce.number().int().min(1).max(60),
    max_nights: z.coerce.number().int().min(1).max(365),
    payment_policy: z.enum(["deposit", "full"]),
    deposit_percent: z.coerce.number().int().min(10).max(100),
    cancellation_policy: z.string().trim().min(10).max(1000),
    amenities: z.array(z.string().regex(/^[a-z_]+$/)).max(40),
    house_rules: z
      .string()
      .max(2000)
      .transform((v) =>
        v
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean)
          .slice(0, 20),
      ),
    host_display_name: optionalText(80),
    host_bio: optionalText(1000),
    host_phone: z
      .string()
      .trim()
      .transform((v, ctx) => {
        if (v === "") return null;
        const e164 = normalizePhone(v);
        if (!e164) {
          ctx.addIssue({ code: "custom", message: "Enter a valid WhatsApp number" });
          return z.NEVER;
        }
        return e164;
      }),
    host_languages: z.string().transform((v) =>
      v
        .split(",")
        .map((l) => l.trim())
        .filter(Boolean)
        .slice(0, 8),
    ),
    is_published: z.boolean(),
  })
  .refine((v) => v.max_nights >= v.min_nights, { path: ["max_nights"], message: "Must be at least the minimum stay" });

export type PropertySettingsInput = z.output<typeof propertySettingsSchema>;

/** Collect a FormData into the plain object shape expected by propertySettingsSchema. */
export function propertyFormToObject(form: FormData): Record<string, unknown> {
  const str = (k: string) => String(form.get(k) ?? "");
  return {
    slug: str("slug"),
    title: str("title"),
    tagline: str("tagline"),
    description: str("description"),
    address_line: str("address_line"),
    city: str("city"),
    region: str("region"),
    country: str("country") || "Malaysia",
    bedrooms: str("bedrooms"),
    beds: str("beds"),
    bathrooms: str("bathrooms"),
    max_guests: str("max_guests"),
    max_infants: str("max_infants"),
    check_in_time: str("check_in_time").slice(0, 5),
    check_out_time: str("check_out_time").slice(0, 5),
    currency: str("currency") || "MYR",
    weekday_rate: str("weekday_rate"),
    weekend_rate: str("weekend_rate"),
    weekend_days: form.getAll("weekend_days").map(String),
    cleaning_fee: str("cleaning_fee") || "0",
    security_deposit: str("security_deposit") || "0",
    min_nights: str("min_nights"),
    max_nights: str("max_nights"),
    payment_policy: str("payment_policy"),
    deposit_percent: str("deposit_percent") || "50",
    cancellation_policy: str("cancellation_policy"),
    amenities: form.getAll("amenities").map(String),
    house_rules: str("house_rules"),
    host_display_name: str("host_display_name"),
    host_bio: str("host_bio"),
    host_phone: str("host_phone"),
    host_languages: str("host_languages"),
    is_published: form.get("is_published") === "on",
  };
}
