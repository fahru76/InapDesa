import {
  AirVent,
  Baby,
  Coffee,
  CookingPot,
  Flame,
  Laptop,
  Leaf,
  MoonStar,
  Mountain,
  PawPrint,
  PlugZap,
  ShowerHead,
  Sparkles,
  SquareParking,
  Sunset,
  Trees,
  Tv,
  WashingMachine,
  Waves,
  Wifi,
  type LucideIcon,
} from "lucide-react";

export interface Amenity {
  key: string;
  label: string;
  icon: LucideIcon;
}

/** Canonical amenity catalog. Keys are stored in properties.amenities (text[]). */
export const AMENITIES: readonly Amenity[] = [
  { key: "wifi", label: "Fast Wi-Fi", icon: Wifi },
  { key: "air_conditioning", label: "Air conditioning", icon: AirVent },
  { key: "kitchen", label: "Full kitchen", icon: CookingPot },
  { key: "pool", label: "Private pool", icon: Waves },
  { key: "free_parking", label: "Free parking", icon: SquareParking },
  { key: "washer", label: "Washer", icon: WashingMachine },
  { key: "workspace", label: "Dedicated workspace", icon: Laptop },
  { key: "bbq", label: "BBQ grill", icon: Flame },
  { key: "garden", label: "Garden", icon: Trees },
  { key: "hot_water", label: "Hot shower", icon: ShowerHead },
  { key: "family_friendly", label: "Family friendly", icon: Baby },
  { key: "pet_friendly", label: "Pets allowed", icon: PawPrint },
  { key: "breakfast", label: "Breakfast included", icon: Coffee },
  { key: "tv", label: "Smart TV", icon: Tv },
  { key: "ev_charger", label: "EV charger", icon: PlugZap },
  { key: "mountain_view", label: "Mountain view", icon: Mountain },
  { key: "sea_view", label: "Sea view", icon: Sunset },
  { key: "prayer_space", label: "Prayer space", icon: MoonStar },
  { key: "eco", label: "Eco-friendly", icon: Leaf },
] as const;

const BY_KEY = new Map(AMENITIES.map((a) => [a.key, a]));

export function getAmenity(key: string): Amenity {
  return (
    BY_KEY.get(key) ?? {
      key,
      label: key.replace(/_/g, " ").replace(/^\w/, (c) => c.toUpperCase()),
      icon: Sparkles,
    }
  );
}
