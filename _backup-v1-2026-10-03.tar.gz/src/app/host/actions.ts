"use server";

import { revalidatePath } from "next/cache";
import { diffDays, eachNight, isISODate } from "@/lib/dates";
import { toMinor } from "@/lib/pricing";
import { getStripe } from "@/lib/stripe";
import { createAdminClient, requireUser } from "@/lib/supabase/server";
import { propertyFormToObject, propertySettingsSchema } from "@/lib/validation";

export interface ActionResult {
  ok: boolean;
  message?: string;
  errors?: Record<string, string>;
  propertyId?: string;
}

function revalidateHost(slug?: string) {
  revalidatePath("/host", "layout");
  revalidatePath("/");
  if (slug) revalidatePath(`/stays/${slug}`);
}

// ─── Property settings ─────────────────────────────────────────────────────

export async function saveProperty(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const { supabase, user } = await requireUser();
  const parsed = propertySettingsSchema.safeParse(propertyFormToObject(formData));
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      errors[key] ??= issue.message;
    }
    return { ok: false, message: "Please fix the highlighted fields.", errors };
  }

  const v = parsed.data;
  const row = {
    slug: v.slug,
    title: v.title,
    tagline: v.tagline,
    description: v.description,
    address_line: v.address_line,
    city: v.city,
    region: v.region,
    country: v.country,
    bedrooms: v.bedrooms,
    beds: v.beds,
    bathrooms: v.bathrooms,
    max_guests: v.max_guests,
    max_infants: v.max_infants,
    check_in_time: v.check_in_time,
    check_out_time: v.check_out_time,
    currency: v.currency,
    weekday_rate: toMinor(v.weekday_rate, v.currency),
    weekend_rate: toMinor(v.weekend_rate, v.currency),
    weekend_days: v.weekend_days,
    cleaning_fee: toMinor(v.cleaning_fee, v.currency),
    security_deposit: toMinor(v.security_deposit, v.currency),
    min_nights: v.min_nights,
    max_nights: v.max_nights,
    payment_policy: v.payment_policy,
    deposit_percent: v.payment_policy === "full" ? 100 : v.deposit_percent,
    cancellation_policy: v.cancellation_policy,
    amenities: v.amenities,
    house_rules: v.house_rules,
    host_display_name: v.host_display_name,
    host_bio: v.host_bio,
    host_phone: v.host_phone,
    host_languages: v.host_languages,
    is_published: v.is_published,
  };

  const id = String(formData.get("id") ?? "");
  const result = id
    ? await supabase.from("properties").update(row).eq("id", id).eq("host_id", user.id).select("id, slug").single()
    : await supabase
        .from("properties")
        .insert({ ...row, host_id: user.id })
        .select("id, slug")
        .single();

  if (result.error) {
    if (result.error.code === "23505") return { ok: false, message: "That URL slug is taken.", errors: { slug: "Already in use — try another." } };
    return { ok: false, message: result.error.message };
  }

  revalidateHost(result.data.slug);
  return { ok: true, message: id ? "Changes saved." : "Property created.", propertyId: result.data.id };
}

// ─── Availability ──────────────────────────────────────────────────────────

export async function setBlockedRange(propertyId: string, from: string, to: string, blocked: boolean, reason?: string): Promise<ActionResult> {
  const { supabase } = await requireUser();
  if (!isISODate(from) || !isISODate(to) || to < from) return { ok: false, message: "Invalid date range." };
  if (diffDays(from, to) > 366) return { ok: false, message: "Select at most one year at a time." };

  const days = [...eachNight(from, to), to]; // inclusive range
  if (blocked) {
    const { error } = await supabase.from("blocked_dates").upsert(
      days.map((date) => ({ property_id: propertyId, date, reason: reason?.slice(0, 200) || null })),
      { onConflict: "property_id,date", ignoreDuplicates: true },
    );
    if (error) return { ok: false, message: error.message };
  } else {
    const { error } = await supabase.from("blocked_dates").delete().eq("property_id", propertyId).gte("date", from).lte("date", to);
    if (error) return { ok: false, message: error.message };
  }
  revalidatePath("/host/calendar");
  const { data: prop } = await supabase.from("properties").select("slug").eq("id", propertyId).maybeSingle();
  if (prop) revalidatePath(`/stays/${prop.slug}`);
  return { ok: true, message: `${days.length} night${days.length > 1 ? "s" : ""} ${blocked ? "closed" : "opened"}.` };
}

// ─── Booking operations ────────────────────────────────────────────────────

export async function checkInBooking(bookingId: string, balanceCollected: boolean): Promise<ActionResult> {
  const { supabase } = await requireUser();
  const { error } = await supabase.rpc("host_check_in_booking", { p_booking_id: bookingId, p_balance_collected: balanceCollected });
  if (error) return { ok: false, message: error.message };
  revalidateHost();
  return { ok: true, message: "Guest checked in." };
}

export async function cancelBooking(bookingId: string, reason: string, refund: boolean): Promise<ActionResult> {
  const { supabase } = await requireUser();
  // Ownership + status rules are enforced inside the SECURITY DEFINER function.
  const { data: booking, error } = await supabase.rpc("host_cancel_booking", { p_booking_id: bookingId, p_reason: reason });
  if (error) return { ok: false, message: error.message };

  let message = "Booking cancelled.";
  if (refund && booking.stripe_payment_intent_id && booking.amount_paid > 0) {
    try {
      const stripe = getStripe();
      const intent = await stripe.paymentIntents.retrieve(booking.stripe_payment_intent_id);
      if (intent.status === "succeeded") {
        const refundObj = await stripe.refunds.create(
          { payment_intent: intent.id, reason: "requested_by_customer", metadata: { booking_id: booking.id, reference: booking.reference } },
          { idempotencyKey: `host-cancel-refund-${booking.id}` },
        );
        await createAdminClient().rpc("record_refund", {
          p_booking_id: booking.id,
          p_refund_id: refundObj.id,
          p_amount: refundObj.amount,
          p_currency: refundObj.currency,
        });
        message = "Booking cancelled and the online payment refunded.";
      }
    } catch (err) {
      console.error("[host] refund failed", err);
      message = "Booking cancelled, but the refund failed — issue it from the Stripe dashboard.";
    }
  }
  revalidateHost();
  return { ok: true, message };
}

// ─── Photos ────────────────────────────────────────────────────────────────

export async function addPropertyImage(propertyId: string, storagePath: string, url: string, alt: string): Promise<ActionResult> {
  const { supabase } = await requireUser();
  if (!storagePath.startsWith(`${propertyId}/`)) return { ok: false, message: "Invalid upload path." };
  const { data: last } = await supabase
    .from("property_images")
    .select("sort_order")
    .eq("property_id", propertyId)
    .order("sort_order", { ascending: false })
    .limit(1)
    .maybeSingle();
  const { error } = await supabase.from("property_images").insert({
    property_id: propertyId,
    storage_path: storagePath,
    url,
    alt: alt.slice(0, 200),
    sort_order: (last?.sort_order ?? -1) + 1,
  });
  if (error) return { ok: false, message: error.message };
  revalidateHost(await slugFor(propertyId));
  return { ok: true };
}

export async function deletePropertyImage(imageId: string): Promise<ActionResult> {
  const { supabase } = await requireUser();
  const { data: img, error } = await supabase.from("property_images").select("*").eq("id", imageId).maybeSingle();
  if (error || !img) return { ok: false, message: "Photo not found." };
  if (img.storage_path) await supabase.storage.from("property-images").remove([img.storage_path]);
  const { error: delErr } = await supabase.from("property_images").delete().eq("id", imageId);
  if (delErr) return { ok: false, message: delErr.message };
  revalidateHost(await slugFor(img.property_id));
  return { ok: true };
}

export async function updateImageAlt(imageId: string, alt: string): Promise<ActionResult> {
  const { supabase } = await requireUser();
  const { data, error } = await supabase.from("property_images").update({ alt: alt.slice(0, 200) }).eq("id", imageId).select("property_id").single();
  if (error) return { ok: false, message: error.message };
  revalidateHost(await slugFor(data.property_id));
  return { ok: true };
}

export async function setCoverImage(imageId: string): Promise<ActionResult> {
  const { supabase } = await requireUser();
  const { data: img } = await supabase.from("property_images").select("property_id").eq("id", imageId).maybeSingle();
  if (!img) return { ok: false, message: "Photo not found." };
  const { data: all, error } = await supabase.from("property_images").select("id").eq("property_id", img.property_id).order("sort_order");
  if (error) return { ok: false, message: error.message };
  const ordered = [imageId, ...(all ?? []).map((r) => r.id).filter((id) => id !== imageId)];
  for (const [i, id] of ordered.entries()) {
    const { error: updErr } = await supabase.from("property_images").update({ sort_order: i }).eq("id", id);
    if (updErr) return { ok: false, message: updErr.message };
  }
  revalidateHost(await slugFor(img.property_id));
  return { ok: true };
}

async function slugFor(propertyId: string): Promise<string | undefined> {
  const { supabase } = await requireUser();
  const { data } = await supabase.from("properties").select("slug").eq("id", propertyId).maybeSingle();
  return data?.slug;
}
