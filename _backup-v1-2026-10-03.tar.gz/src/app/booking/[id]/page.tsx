import { CalendarDays, CircleAlert, CircleCheck, Clock, Hourglass, MapPin, MessageCircle, Users, XCircle } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PriceBreakdown } from "@/components/booking/price-breakdown";
import { PaymentStatusPoller, QrPass, ReceiptActions } from "@/components/receipt/receipt-client";
import { buttonStyles } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { getGuestBooking, syncPendingBooking, type BookingWithProperty } from "@/lib/booking-service";
import { formatDateLong, formatTime } from "@/lib/dates";
import { publicEnv } from "@/lib/env";
import { whatsappLink } from "@/lib/messaging";
import { formatMoney, guestSummary, quoteFromSnapshot } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Your booking", robots: { index: false, follow: false } };

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";
const PAID = new Set(["confirmed", "paid_in_full", "checked_in", "completed"]);

export default async function BookingReceiptPage({ params, searchParams }: Props) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const token = one(sp.token);
  let booking = await getGuestBooking(id, token);
  if (!booking) notFound();

  // The webhook may not have arrived yet — reconcile directly with Stripe.
  if (booking.status === "pending_payment" || booking.status === "expired") {
    await syncPendingBooking(booking);
    booking = (await getGuestBooking(id, token)) ?? booking;
  }

  const redirectFailed = one(sp.redirect_status) === "failed";

  if (PAID.has(booking.status)) return <Confirmed booking={booking} />;
  if (booking.status === "pending_payment" && !redirectFailed) return <Processing booking={booking} />;
  return <NotCompleted booking={booking} failed={redirectFailed} />;
}

function Confirmed({ booking }: { booking: BookingWithProperty }) {
  const p = booking.property;
  const quote = quoteFromSnapshot(booking);
  const outstanding = Math.max(0, booking.total_amount - booking.amount_paid);
  const location = [p.address_line, p.city, p.region].filter(Boolean).join(", ");
  const passUrl = `${publicEnv.siteUrl}/host/check-in/${booking.reference}`;

  return (
    <div className="surface-muted min-h-[calc(100dvh-4rem)]">
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:py-14">
        <div className="text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-full bg-brand-600 text-white shadow-[0_12px_32px_-8px_rgb(5_150_105/0.6)]">
            <CircleCheck className="size-7" aria-hidden />
          </div>
          <h1 className="mt-5 text-3xl font-semibold tracking-tight text-balance">You&apos;re going to {p.city}!</h1>
          <p className="mx-auto mt-2 max-w-xl text-zinc-600 dark:text-zinc-400">
            {booking.status === "paid_in_full" ? "Your stay is fully paid." : "Your deposit is in and your dates are locked."} Save this page — it&apos;s your check-in pass.
          </p>
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl border border-zinc-200/80 bg-white shadow-float dark:border-zinc-800/80 dark:bg-zinc-900">
          <div className="grid md:grid-cols-[1fr_280px]">
            <div className="p-6 sm:p-8">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Booking {booking.reference}</p>
                  <h2 className="mt-1 text-xl font-semibold tracking-tight">{p.title}</h2>
                </div>
                <StatusBadge status={booking.status} />
              </div>

              <dl className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
                <Detail icon={CalendarDays} label="Check-in" value={formatDateLong(booking.check_in)} sub={`From ${formatTime(p.check_in_time)}`} />
                <Detail icon={CalendarDays} label="Check-out" value={formatDateLong(booking.check_out)} sub={`By ${formatTime(p.check_out_time)}`} />
                <Detail icon={Users} label="Guests" value={guestSummary(booking)} sub={`${booking.guest_name} · ${booking.guest_email}`} />
                <Detail icon={MapPin} label="Address" value={location || p.city} sub={p.country} />
              </dl>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl bg-brand-50 p-4 dark:bg-brand-500/10">
                  <p className="text-xs font-semibold uppercase tracking-wider text-brand-700 dark:text-brand-300">Paid</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight tabular-nums">{formatMoney(booking.amount_paid, booking.currency)}</p>
                </div>
                <div className="rounded-2xl bg-zinc-100 p-4 dark:bg-zinc-800/60">
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Due at check-in</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight tabular-nums">{formatMoney(outstanding, booking.currency)}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center border-t border-dashed border-zinc-300 bg-gradient-to-b from-zinc-50 to-white p-8 md:border-t-0 md:border-l dark:border-zinc-700 dark:from-zinc-900 dark:to-zinc-950">
              <QrPass value={passUrl} reference={booking.reference} />
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
          <ReceiptActions
            title={p.title}
            reference={booking.reference}
            checkIn={booking.check_in}
            checkOut={booking.check_out}
            checkInTime={p.check_in_time}
            checkOutTime={p.check_out_time}
            location={location || p.city}
            timeZone={p.timezone}
          />
          {p.host_phone && (
            <a
              href={whatsappLink(p.host_phone, `Hi${p.host_display_name ? ` ${p.host_display_name}` : ""}! I've booked ${p.title} (${booking.reference}).`)}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonStyles({ variant: "whatsapp", size: "sm", className: "no-print" })}
            >
              <MessageCircle className="size-4" aria-hidden /> Message {p.host_display_name ?? "host"}
            </a>
          )}
        </div>

        <section className="card mt-8 p-6 sm:p-8">
          <h2 className="mb-4 text-lg font-semibold tracking-tight">Price details</h2>
          <PriceBreakdown quote={quote} hideSplit />
          <p className="mt-4 text-xs leading-5 text-zinc-500">{p.cancellation_policy}</p>
        </section>
      </div>
    </div>
  );
}

function Processing({ booking }: { booking: BookingWithProperty }) {
  return (
    <StateCard
      icon={Hourglass}
      tone="neutral"
      title="Almost there…"
      body={`We're confirming your payment of ${formatMoney(booking.amount_due_now, booking.currency)} for ${booking.property.title}.`}
    >
      <PaymentStatusPoller />
    </StateCard>
  );
}

function NotCompleted({ booking, failed }: { booking: BookingWithProperty; failed: boolean }) {
  const rebook = `/stays/${booking.property.slug}?${new URLSearchParams({
    checkIn: booking.check_in,
    checkOut: booking.check_out,
    adults: String(booking.adults),
    children: String(booking.children),
    infants: String(booking.infants),
  })}`;

  if (booking.status === "cancelled") {
    const conflict = booking.cancellation_reason === "payment_after_hold_conflict";
    return (
      <StateCard
        icon={XCircle}
        tone="danger"
        title="This booking was cancelled"
        body={
          conflict
            ? "Your hold expired and the dates were taken before payment completed. Your payment has been refunded in full automatically."
            : (booking.cancellation_reason ?? "Please contact your host for details.")
        }
      >
        <Link href={`/stays/${booking.property.slug}`} className={buttonStyles({ className: "mt-6" })}>
          Find other dates
        </Link>
      </StateCard>
    );
  }

  return (
    <StateCard
      icon={failed ? CircleAlert : Clock}
      tone="warning"
      title={failed ? "Payment didn't go through" : "Your hold has expired"}
      body={failed ? "No money was taken. You can try again with another payment method." : "No payment was taken and the dates were released. They may still be available."}
    >
      <Link href={rebook} className={buttonStyles({ className: "mt-6" })}>
        {failed ? "Try again" : "Check availability"}
      </Link>
    </StateCard>
  );
}

function StateCard({
  icon: Icon,
  tone,
  title,
  body,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  tone: "neutral" | "warning" | "danger";
  title: string;
  body: string;
  children?: React.ReactNode;
}) {
  const toneClass = {
    neutral: "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
    warning: "bg-terracotta-500/10 text-terracotta-600",
    danger: "bg-red-50 text-red-600 dark:bg-red-500/10",
  }[tone];
  return (
    <div className="mx-auto max-w-lg px-4 py-20 text-center">
      <div className={`mx-auto grid size-14 place-items-center rounded-full ${toneClass}`}>
        <Icon className="size-7" />
      </div>
      <h1 className="mt-5 text-2xl font-semibold tracking-tight">{title}</h1>
      <p className="mt-2 text-zinc-600 dark:text-zinc-400">{body}</p>
      {children}
    </div>
  );
}

function Detail({ icon: Icon, label, value, sub }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; sub?: string | null }) {
  return (
    <div className="flex gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-zinc-400" />
      <div className="min-w-0">
        <dt className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{label}</dt>
        <dd className="mt-0.5 font-medium">{value}</dd>
        {sub && <dd className="break-words text-zinc-500">{sub}</dd>}
      </div>
    </div>
  );
}
