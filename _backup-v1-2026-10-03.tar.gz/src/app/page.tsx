import { ArrowRight, Images, MapPin, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { formatMoney } from "@/lib/pricing";
import { getPublishedProperties } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const properties = await getPublishedProperties();

  return (
    <div className="pb-20">
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60rem_30rem_at_10%_-10%,rgb(16_185_129/0.12),transparent),radial-gradient(40rem_24rem_at_90%_0%,rgb(249_115_22/0.10),transparent)]" />
        <div className="relative mx-auto max-w-7xl px-4 pt-16 pb-12 sm:px-6 sm:pt-24 lg:px-8">
          <p className="inline-flex items-center gap-2 rounded-full border border-zinc-200/80 bg-white/70 px-3 py-1 text-xs font-semibold text-zinc-600 backdrop-blur dark:border-zinc-800/80 dark:bg-zinc-900/60 dark:text-zinc-300">
            <Sparkles className="size-3.5 text-terracotta-500" aria-hidden />
            Boutique homestays · Book direct
          </p>
          <h1 className="mt-5 max-w-3xl text-4xl font-semibold tracking-tight text-balance sm:text-5xl lg:text-6xl">
            Stay somewhere that <span className="bg-gradient-to-r from-brand-600 to-brand-800 bg-clip-text text-transparent">feels like home.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg text-zinc-600 dark:text-zinc-400">
            Hand-restored village houses and private villas, hosted by the people who love them. Lock your dates with a small deposit and settle the rest on arrival.
          </p>
          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm font-medium text-zinc-700 dark:text-zinc-300">
            <li className="inline-flex items-center gap-2">
              <ShieldCheck className="size-4 text-brand-600" aria-hidden /> Secure payments by Stripe
            </li>
            <li className="inline-flex items-center gap-2">
              <Wallet className="size-4 text-brand-600" aria-hidden /> FPX, cards, Apple Pay &amp; Google Pay
            </li>
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-labelledby="stays-heading">
        <h2 id="stays-heading" className="mb-6 text-xl font-semibold tracking-tight">
          Our homes
        </h2>

        {properties.length === 0 ? (
          <div className="card grid place-items-center px-6 py-16 text-center">
            <p className="text-lg font-semibold">No homes are published yet</p>
            <p className="mt-2 max-w-md text-sm text-zinc-500">Hosts can create and publish a listing from the host dashboard.</p>
            <Link href="/host/settings" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-brand-700 underline-offset-4 hover:underline">
              Go to host dashboard <ArrowRight className="size-4" aria-hidden />
            </Link>
          </div>
        ) : (
          <ul className="grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {properties.map((p, i) => {
              const cover = p.images[0];
              return (
                <li key={p.id}>
                  <Link href={`/stays/${p.slug}`} className="group block">
                    <div className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-zinc-100 dark:bg-zinc-900">
                      {cover ? (
                        <Image
                          src={cover.url}
                          alt={cover.alt || p.title}
                          fill
                          sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                          className="object-cover transition duration-700 ease-[var(--ease-out-expo)] group-hover:scale-[1.04]"
                          priority={i < 3}
                        />
                      ) : (
                        <div className="grid size-full place-items-center bg-gradient-to-br from-brand-900 via-ink to-zinc-900 text-white/80">
                          <Images className="size-7" aria-hidden />
                        </div>
                      )}
                      <span className="glass absolute top-3 left-3 rounded-full px-3 py-1 text-xs font-semibold">
                        {p.payment_policy === "full" ? "Pay in full" : `${p.deposit_percent}% deposit to book`}
                      </span>
                    </div>
                    <div className="mt-4 flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <h3 className="truncate text-[15px] font-semibold tracking-tight">{p.title}</h3>
                        <p className="mt-0.5 flex items-center gap-1 text-sm text-zinc-500">
                          <MapPin className="size-3.5" aria-hidden /> {p.city}
                          {p.region ? `, ${p.region}` : ""}
                        </p>
                        <p className="mt-0.5 text-sm text-zinc-500">
                          {p.max_guests} guests · {p.bedrooms} bedrooms
                        </p>
                      </div>
                      <p className="shrink-0 text-right text-[15px]">
                        <span className="font-semibold">{formatMoney(Math.min(p.weekday_rate, p.weekend_rate), p.currency)}</span>
                        <span className="text-zinc-500"> / night</span>
                      </p>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
