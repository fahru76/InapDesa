import { ArrowLeft, CalendarDays, CircleAlert, Users } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PriceBreakdown } from "@/components/booking/price-breakdown";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";
import { buttonStyles } from "@/components/ui/button";
import { formatDateLong } from "@/lib/dates";
import { publicEnv } from "@/lib/env";
import { guestSummary, quoteStay, validateGuests, validateStay } from "@/lib/pricing";
import { getAvailability, getPropertyBySlug } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Confirm and pay", robots: { index: false } };

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";
const int = (v: string | string[] | undefined, fallback: number) => {
  const n = Number(one(v));
  return one(v) !== "" && Number.isInteger(n) ? n : fallback;
};

export default async function CheckoutPage({ params, searchParams }: Props) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const property = await getPropertyBySlug(slug);
  if (!property || !property.is_published) notFound();

  const checkIn = one(sp.checkIn);
  const checkOut = one(sp.checkOut);
  const guests = { adults: int(sp.adults, 1), children: int(sp.children, 0), infants: int(sp.infants, 0) };

  const availability = await getAvailability(property);
  const unavailable = new Set([...availability.booked, ...availability.blocked]);
  const stayError = validateStay(property, checkIn, checkOut, availability.from, unavailable);
  const guestError = validateGuests(property, guests);
  const backHref = `/stays/${property.slug}`;

  if (stayError || guestError) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <div className="mx-auto grid size-12 place-items-center rounded-full bg-terracotta-500/10 text-terracotta-600">
          <CircleAlert className="size-6" aria-hidden />
        </div>
        <h1 className="mt-5 text-2xl font-semibold tracking-tight">Let&apos;s adjust your trip</h1>
        <p className="mt-2 text-zinc-600 dark:text-zinc-400">{stayError?.message ?? guestError}</p>
        <Link href={backHref} className={buttonStyles({ className: "mt-8" })}>
          Choose dates
        </Link>
      </div>
    );
  }

  const quote = quoteStay(property, checkIn, checkOut);
  const cover = property.images[0];
  const query = new URLSearchParams({ checkIn, checkOut, adults: String(guests.adults), children: String(guests.children), infants: String(guests.infants) });

  return (
    <div className="surface-muted min-h-[calc(100dvh-4rem)]">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <Link href={`${backHref}?${query}`} className="inline-flex items-center gap-2 text-sm font-medium text-zinc-600 hover:text-ink dark:text-zinc-400 dark:hover:text-white">
          <ArrowLeft className="size-4" aria-hidden /> Back to listing
        </Link>
        <h1 className="mt-4 text-3xl font-semibold tracking-tight">Confirm and pay</h1>

        <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1fr)_420px] lg:gap-12">
          <div className="card order-2 p-6 sm:p-8 lg:order-1">
            <CheckoutFlow
              stripePublishableKey={publicEnv.stripePublishableKey}
              propertyId={property.id}
              propertySlug={property.slug}
              checkIn={checkIn}
              checkOut={checkOut}
              adults={guests.adults}
              children={guests.children}
              infants={guests.infants}
              dueNow={quote.dueNow}
              currency={quote.currency}
              isFullPayment={quote.balanceDue === 0}
            />
          </div>

          <aside className="order-1 lg:order-2">
            <div className="card p-6 lg:sticky lg:top-24">
              <div className="flex gap-4">
                <div className="relative size-24 shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br from-brand-800 to-ink">
                  {cover && <Image src={cover.url} alt={cover.alt || property.title} fill sizes="96px" className="object-cover" />}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{property.city}</p>
                  <p className="mt-1 font-semibold leading-snug tracking-tight">{property.title}</p>
                </div>
              </div>

              <dl className="mt-6 space-y-3 border-y border-zinc-200/80 py-5 text-sm dark:border-zinc-800/80">
                <div className="flex items-start gap-3">
                  <CalendarDays className="mt-0.5 size-4 text-zinc-400" aria-hidden />
                  <div>
                    <dt className="sr-only">Dates</dt>
                    <dd className="font-medium">
                      {formatDateLong(checkIn)} → {formatDateLong(checkOut)}
                    </dd>
                    <dd className="text-zinc-500">
                      {quote.nights} night{quote.nights > 1 ? "s" : ""}
                    </dd>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Users className="mt-0.5 size-4 text-zinc-400" aria-hidden />
                  <div>
                    <dt className="sr-only">Guests</dt>
                    <dd className="font-medium">{guestSummary(guests)}</dd>
                  </div>
                </div>
              </dl>

              <PriceBreakdown quote={quote} className="mt-5" />

              <p className="mt-5 text-xs leading-5 text-zinc-500">{property.cancellation_policy}</p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
