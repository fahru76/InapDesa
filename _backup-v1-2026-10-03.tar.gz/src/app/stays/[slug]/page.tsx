import { Bath, BedDouble, Clock, DoorOpen, ExternalLink, MapPin, ShieldCheck, Users } from "lucide-react";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BookingProvider } from "@/components/booking/booking-context";
import { BookingPanel } from "@/components/booking/booking-panel";
import { AvailabilitySection, MobileBookingBar } from "@/components/booking/booking-sections";
import { Gallery } from "@/components/property/gallery";
import { AmenityList, ExpandableText, HostCard } from "@/components/property/property-sections";
import { addDays, formatTime } from "@/lib/dates";
import { whatsappLink } from "@/lib/messaging";
import { formatMoney } from "@/lib/pricing";
import { getAvailability, getPropertyBySlug } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const int = (v: string | string[] | undefined) => {
  const raw = one(v);
  if (raw === undefined) return undefined;
  const n = Number(raw);
  return Number.isInteger(n) ? n : undefined;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const property = await getPropertyBySlug(slug);
  if (!property) return { title: "Stay not found" };
  return {
    title: property.title,
    description: property.tagline ?? property.description.slice(0, 160),
    openGraph: { images: property.images[0] ? [{ url: property.images[0].url }] : undefined },
  };
}

export default async function StayPage({ params, searchParams }: Props) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const property = await getPropertyBySlug(slug);
  if (!property || !property.is_published) notFound();

  const availability = await getAvailability(property);
  const location = [property.city, property.region, property.country].filter(Boolean).join(", ");
  const mapsHref =
    property.latitude !== null && property.longitude !== null
      ? `https://www.google.com/maps/search/?api=1&query=${property.latitude},${property.longitude}`
      : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;

  return (
    <BookingProvider
      property={property}
      today={availability.from}
      maxDate={addDays(availability.to, -1)}
      booked={availability.booked}
      blocked={availability.blocked}
      initial={{ checkIn: one(sp.checkIn), checkOut: one(sp.checkOut), adults: int(sp.adults), children: int(sp.children), infants: int(sp.infants) }}
    >
      <div className="mx-auto max-w-7xl px-4 pt-6 pb-32 sm:px-6 lg:px-8 lg:pb-16">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold tracking-tight text-balance sm:text-3xl lg:text-[2.1rem]">{property.title}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
            <a href={mapsHref} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-medium underline-offset-4 hover:underline">
              <MapPin className="size-4" aria-hidden />
              {location}
            </a>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="size-4 text-brand-600" aria-hidden />
              Book direct with the host
            </span>
          </div>
        </header>

        <Gallery images={property.images.map((i) => ({ id: i.id, url: i.url, alt: i.alt }))} title={property.title} />

        <div className="mt-10 grid gap-12 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-16">
          <div className="min-w-0">
            {property.tagline && <p className="text-lg font-medium tracking-tight text-zinc-800 dark:text-zinc-200">{property.tagline}</p>}

            <ul className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Fact icon={Users} label={`${property.max_guests} guests`} />
              <Fact icon={DoorOpen} label={`${property.bedrooms} bedroom${property.bedrooms === 1 ? "" : "s"}`} />
              <Fact icon={BedDouble} label={`${property.beds} bed${property.beds === 1 ? "" : "s"}`} />
              <Fact icon={Bath} label={`${Number(property.bathrooms)} bath${Number(property.bathrooms) === 1 ? "" : "s"}`} />
            </ul>

            <Section title="About this home" first>
              <ExpandableText text={property.description} />
            </Section>

            {property.amenities.length > 0 && (
              <Section title="What this place offers">
                <AmenityList amenities={property.amenities} />
              </Section>
            )}

            <AvailabilitySection />

            <Section title="Good to know">
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="card p-5">
                  <h3 className="flex items-center gap-2 font-semibold">
                    <Clock className="size-4 text-brand-600" aria-hidden /> Arrival &amp; departure
                  </h3>
                  <dl className="mt-3 space-y-1.5 text-sm text-zinc-600 dark:text-zinc-400">
                    <div className="flex justify-between">
                      <dt>Check-in</dt>
                      <dd className="font-medium text-ink dark:text-white">From {formatTime(property.check_in_time)}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt>Check-out</dt>
                      <dd className="font-medium text-ink dark:text-white">By {formatTime(property.check_out_time)}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt>Minimum stay</dt>
                      <dd className="font-medium text-ink dark:text-white">
                        {property.min_nights} night{property.min_nights === 1 ? "" : "s"}
                      </dd>
                    </div>
                  </dl>
                </div>
                <div className="card p-5">
                  <h3 className="flex items-center gap-2 font-semibold">
                    <ShieldCheck className="size-4 text-brand-600" aria-hidden /> Payment policy
                  </h3>
                  <p className="mt-3 text-sm leading-6 text-zinc-600 dark:text-zinc-400">
                    {property.payment_policy === "full"
                      ? "Pay in full today to confirm your stay."
                      : `Pay a ${property.deposit_percent}% deposit today to lock your dates. The remainder is settled on check-in.`}
                    {property.security_deposit > 0 &&
                      ` A refundable security deposit of ${formatMoney(property.security_deposit, property.currency)} applies.`}
                  </p>
                  <p className="mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{property.cancellation_policy}</p>
                </div>
              </div>
              {property.house_rules.length > 0 && (
                <ul className="mt-6 grid gap-2 text-sm text-zinc-700 sm:grid-cols-2 dark:text-zinc-300">
                  {property.house_rules.map((rule) => (
                    <li key={rule} className="flex items-start gap-2">
                      <span className="mt-2 size-1.5 shrink-0 rounded-full bg-terracotta-500" aria-hidden />
                      {rule}
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title="Where you'll be">
              <div className="card flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-center">
                <div>
                  <p className="font-semibold">{location}</p>
                  <p className="mt-1 text-sm text-zinc-500">The exact address is shared once your booking is confirmed.</p>
                </div>
                <a
                  href={mapsHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 self-start rounded-xl border border-zinc-200/80 px-3.5 py-2 text-sm font-semibold transition hover:shadow-soft sm:self-auto dark:border-zinc-800/80"
                >
                  Open in Maps <ExternalLink className="size-3.5" aria-hidden />
                </a>
              </div>
            </Section>

            {property.host_display_name && (
              <Section title="Meet your host">
                <HostCard
                  name={property.host_display_name}
                  bio={property.host_bio}
                  avatarUrl={property.host_avatar_url}
                  languages={property.host_languages}
                  hostSince={property.host_since}
                  whatsappHref={property.host_phone ? whatsappLink(property.host_phone, `Hi! I'm interested in staying at ${property.title}.`) : null}
                />
              </Section>
            )}
          </div>

          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <BookingPanel />
            </div>
          </aside>
        </div>
      </div>

      <MobileBookingBar />
    </BookingProvider>
  );
}

function Section({ title, first, children }: { title: string; first?: boolean; children: React.ReactNode }) {
  return (
    <section className={`border-t border-zinc-200/80 py-10 dark:border-zinc-800/80 ${first ? "mt-8" : ""}`}>
      <h2 className="mb-5 text-xl font-semibold tracking-tight">{title}</h2>
      {children}
    </section>
  );
}

function Fact({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <li className="surface-muted flex items-center gap-2.5 rounded-2xl px-4 py-3 text-sm font-medium">
      <Icon className="size-4 text-zinc-500" />
      {label}
    </li>
  );
}
