"use client";

import { Elements, ExpressCheckoutElement, PaymentElement, useElements, useStripe } from "@stripe/react-stripe-js";
import { loadStripe, type Appearance, type Stripe as StripeJs } from "@stripe/stripe-js";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, CircleAlert, Hourglass, Lock } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { formatMoney } from "@/lib/pricing";
import { cn } from "@/lib/utils";
import { guestDetailsSchema } from "@/lib/validation";
import { Button } from "@/components/ui/button";
import { Field, inputStyles } from "@/components/ui/field";

interface CheckoutFlowProps {
  stripePublishableKey: string;
  propertyId: string;
  propertySlug: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  infants: number;
  dueNow: number;
  currency: string;
  isFullPayment: boolean;
}

interface PaymentSession {
  bookingId: string;
  accessToken: string;
  clientSecret: string;
  holdExpiresAt: string;
  reference: string;
}

type FieldErrors = Partial<Record<"name" | "email" | "phone" | "specialRequests", string>>;

let stripePromise: Promise<StripeJs | null> | null = null;
const getStripe = (key: string) => (stripePromise ??= loadStripe(key));

export function CheckoutFlow(props: CheckoutFlowProps) {
  const [session, setSession] = useState<PaymentSession | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", specialRequests: "" });
  const [errors, setErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState<{ message: string; datesTaken: boolean } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const backHref = `/stays/${props.propertySlug}?${new URLSearchParams({
    checkIn: props.checkIn,
    checkOut: props.checkOut,
    adults: String(props.adults),
    children: String(props.children),
    infants: String(props.infants),
  })}`;

  async function onSubmitDetails(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const parsed = guestDetailsSchema.safeParse(form);
    if (!parsed.success) {
      const next: FieldErrors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof FieldErrors;
        next[key] ??= issue.message;
      }
      setErrors(next);
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          propertyId: props.propertyId,
          checkIn: props.checkIn,
          checkOut: props.checkOut,
          adults: props.adults,
          children: props.children,
          infants: props.infants,
          guest: parsed.data,
        }),
      });
      const data = (await res.json()) as Partial<PaymentSession> & { error?: string; code?: string };
      if (!res.ok || !data.clientSecret || !data.bookingId || !data.accessToken || !data.holdExpiresAt || !data.reference) {
        setFormError({ message: data.error ?? "We couldn't start your booking. Please try again.", datesTaken: data.code === "unavailable" });
        return;
      }
      setSession(data as PaymentSession);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setFormError({ message: "Network error — check your connection and try again.", datesTaken: false });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div>
      <Steps current={session ? 2 : 1} />

      <AnimatePresence mode="wait" initial={false}>
        {!session ? (
          <motion.form
            key="details"
            onSubmit={onSubmitDetails}
            noValidate
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="mt-8 space-y-5"
          >
            <h2 className="text-xl font-semibold tracking-tight">Who&apos;s staying?</h2>
            <Field label="Full name" htmlFor="name" error={errors.name}>
              <input id="name" autoComplete="name" className={inputStyles} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} aria-invalid={!!errors.name} />
            </Field>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Email" htmlFor="email" error={errors.email} hint="Your receipt and check-in pass go here.">
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  inputMode="email"
                  className={inputStyles}
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  aria-invalid={!!errors.email}
                />
              </Field>
              <Field label="Mobile (WhatsApp)" htmlFor="phone" error={errors.phone} hint="e.g. 012-345 6789 or +65 9123 4567">
                <input
                  id="phone"
                  type="tel"
                  autoComplete="tel"
                  inputMode="tel"
                  className={inputStyles}
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  aria-invalid={!!errors.phone}
                />
              </Field>
            </div>
            <Field label="Message to host (optional)" htmlFor="requests" error={errors.specialRequests} hint="Arrival time, celebrations, dietary needs…">
              <textarea
                id="requests"
                rows={3}
                maxLength={1000}
                className={cn(inputStyles, "resize-none")}
                value={form.specialRequests}
                onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
              />
            </Field>

            {formError && (
              <div role="alert" className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-500/10 dark:text-red-300">
                <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
                <div>
                  <p>{formError.message}</p>
                  {formError.datesTaken && (
                    <Link href={backHref} className="mt-1 inline-block font-semibold underline underline-offset-4">
                      Choose different dates
                    </Link>
                  )}
                </div>
              </div>
            )}

            <Button type="submit" size="lg" className="w-full" loading={submitting}>
              Continue to payment
            </Button>
            <p className="text-center text-xs text-zinc-500">Your dates are held for you while you pay.</p>
          </motion.form>
        ) : (
          <motion.div
            key="payment"
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 16 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="mt-8"
          >
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-xl font-semibold tracking-tight">Pay securely</h2>
              <HoldTimer expiresAt={session.holdExpiresAt} />
            </div>
            <StripeElements publishableKey={props.stripePublishableKey} clientSecret={session.clientSecret}>
              <PaymentStep session={session} amountLabel={formatMoney(props.dueNow, props.currency)} isFullPayment={props.isFullPayment} onBack={() => setSession(null)} />
            </StripeElements>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StripeElements({ publishableKey, clientSecret, children }: { publishableKey: string; clientSecret: string; children: ReactNode }) {
  const appearance = useMemo<Appearance>(() => {
    const dark = typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches;
    const border = dark ? "rgb(39 39 42 / 0.8)" : "rgb(228 228 231 / 0.8)";
    return {
      theme: dark ? "night" : "stripe",
      variables: {
        colorPrimary: "#059669",
        colorText: dark ? "#f4f4f5" : "#0f172a",
        colorDanger: "#dc2626",
        borderRadius: "12px",
        fontFamily: '"Plus Jakarta Sans Variable", ui-sans-serif, system-ui, sans-serif',
        spacingUnit: "4px",
      },
      rules: {
        ".Input": { boxShadow: "0 1px 2px rgb(15 23 42 / 0.04)", borderColor: border },
        ".Input:focus": { boxShadow: "0 0 0 4px rgb(16 185 129 / 0.15)", borderColor: "#10b981" },
        ".AccordionItem": { borderColor: border },
      },
    };
  }, []);

  return (
    <Elements stripe={getStripe(publishableKey)} options={{ clientSecret, appearance }}>
      {children}
    </Elements>
  );
}

function PaymentStep({ session, amountLabel, isFullPayment, onBack }: { session: PaymentSession; amountLabel: string; isFullPayment: boolean; onBack: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);
  const [ready, setReady] = useState(false);
  const [expressAvailable, setExpressAvailable] = useState(false);

  const returnUrl = () => `${window.location.origin}/booking/${session.bookingId}?token=${session.accessToken}`;

  async function confirm() {
    if (!stripe || !elements) return;
    setPaying(true);
    setError(null);
    const { error: submitError } = await elements.submit();
    if (submitError) {
      setError(submitError.message ?? "Please check your payment details.");
      setPaying(false);
      return;
    }
    const { error: confirmError } = await stripe.confirmPayment({
      elements,
      clientSecret: session.clientSecret,
      confirmParams: { return_url: returnUrl() },
    });
    // Only reached on immediate errors; success redirects to return_url.
    setError(confirmError.message ?? "Payment failed. Please try another method.");
    setPaying(false);
  }

  return (
    <div className="space-y-5">
      <div className={cn(!expressAvailable && "hidden")}>
        <ExpressCheckoutElement
          options={{ buttonHeight: 48, buttonType: { applePay: "book", googlePay: "book" } }}
          onReady={({ availablePaymentMethods }) => setExpressAvailable(!!availablePaymentMethods && Object.values(availablePaymentMethods).some(Boolean))}
          onConfirm={async () => {
            if (!stripe || !elements) return;
            const { error: confirmError } = await stripe.confirmPayment({
              elements,
              clientSecret: session.clientSecret,
              confirmParams: { return_url: returnUrl() },
            });
            if (confirmError) setError(confirmError.message ?? "Payment failed.");
          }}
        />
        <div className="my-5 flex items-center gap-3 text-xs font-medium uppercase tracking-wider text-zinc-400">
          <span className="h-px flex-1 bg-zinc-200 dark:bg-zinc-800" /> or pay another way <span className="h-px flex-1 bg-zinc-200 dark:bg-zinc-800" />
        </div>
      </div>

      {!ready && <div className="skeleton h-48 w-full" aria-hidden />}
      <PaymentElement
        onReady={() => setReady(true)}
        options={{ layout: { type: "accordion", defaultCollapsed: false, radios: "if_multiple", spacedAccordionItems: true }, business: { name: "InapDesa" } }}
      />

      {error && (
        <p role="alert" className="flex items-start gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 dark:bg-red-500/10 dark:text-red-300">
          <CircleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
          {error}
        </p>
      )}

      <Button size="lg" className="w-full" onClick={confirm} loading={paying} disabled={!stripe || !ready}>
        <Lock className="size-4" aria-hidden />
        Pay {amountLabel} {isFullPayment ? "now" : "deposit"}
      </Button>

      <div className="flex items-center justify-between text-xs text-zinc-500">
        <button type="button" onClick={onBack} className="inline-flex items-center gap-1 font-medium hover:text-ink dark:hover:text-white">
          <ArrowLeft className="size-3.5" aria-hidden /> Edit details
        </button>
        <span>
          Ref <span className="font-mono font-semibold">{session.reference}</span>
        </span>
      </div>
    </div>
  );
}

function HoldTimer({ expiresAt }: { expiresAt: string }) {
  const [remaining, setRemaining] = useState(() => Math.max(0, Date.parse(expiresAt) - Date.now()));
  useEffect(() => {
    const t = setInterval(() => setRemaining(Math.max(0, Date.parse(expiresAt) - Date.now())), 1000);
    return () => clearInterval(t);
  }, [expiresAt]);
  const mins = Math.floor(remaining / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);
  const low = remaining < 3 * 60_000;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold tabular-nums",
        low ? "bg-terracotta-500/10 text-terracotta-600" : "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
      )}
      role="timer"
    >
      <Hourglass className="size-3.5" aria-hidden />
      {remaining > 0 ? `Dates held for ${mins}:${String(secs).padStart(2, "0")}` : "Hold expired — dates re-checked when you pay"}
    </span>
  );
}

function Steps({ current }: { current: 1 | 2 }) {
  const steps = ["Your details", "Payment"];
  return (
    <ol className="flex items-center gap-3 text-sm">
      {steps.map((label, i) => {
        const n = i + 1;
        const done = n < current;
        const active = n === current;
        return (
          <li key={label} className="flex items-center gap-3">
            <span
              className={cn(
                "grid size-7 place-items-center rounded-full text-xs font-bold transition",
                active ? "bg-ink text-white dark:bg-white dark:text-ink" : done ? "bg-brand-600 text-white" : "bg-zinc-100 text-zinc-500 dark:bg-zinc-800",
              )}
            >
              {done ? "✓" : n}
            </span>
            <span className={cn("font-medium", active ? "text-ink dark:text-white" : "text-zinc-500")}>{label}</span>
            {i < steps.length - 1 && <span className="h-px w-8 bg-zinc-200 dark:bg-zinc-800" aria-hidden />}
          </li>
        );
      })}
    </ol>
  );
}
