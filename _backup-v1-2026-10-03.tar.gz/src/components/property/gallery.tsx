"use client";

import { AnimatePresence, motion, type PanInfo } from "framer-motion";
import { ChevronLeft, ChevronRight, Grid2x2, Images, X } from "lucide-react";
import Image from "next/image";
import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/utils";

export interface GalleryImage {
  id: string;
  url: string;
  alt: string;
}

const noopSubscribe = () => () => {};

export function Gallery({ images, title }: { images: GalleryImage[]; title: string }) {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [mobileIndex, setMobileIndex] = useState(0);
  const scroller = useRef<HTMLDivElement>(null);

  if (images.length === 0) {
    return (
      <div className="relative grid aspect-[16/9] place-items-center overflow-hidden rounded-3xl bg-gradient-to-br from-brand-900 via-ink to-zinc-900 text-white sm:aspect-[21/9]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgb(249_115_22/0.25),transparent_45%),radial-gradient(circle_at_80%_70%,rgb(16_185_129/0.25),transparent_45%)]" />
        <div className="relative text-center">
          <Images className="mx-auto size-8 opacity-80" aria-hidden />
          <p className="mt-3 text-lg font-semibold tracking-tight">{title}</p>
          <p className="mt-1 text-sm text-white/70">Photos coming soon</p>
        </div>
      </div>
    );
  }

  const onScroll = () => {
    const el = scroller.current;
    if (el) setMobileIndex(Math.round(el.scrollLeft / el.clientWidth));
  };

  const grid = images.slice(0, 5);

  return (
    <>
      {/* Mobile: swipeable carousel */}
      <div className="relative -mx-4 sm:hidden">
        <div ref={scroller} onScroll={onScroll} className="scrollbar-none flex snap-x snap-mandatory overflow-x-auto">
          {images.map((img, i) => (
            <button key={img.id} type="button" onClick={() => setLightbox(i)} className="relative aspect-[4/3] w-full shrink-0 snap-center" aria-label={`Open photo ${i + 1}`}>
              <Image src={img.url} alt={img.alt || `${title} photo ${i + 1}`} fill sizes="100vw" className="object-cover" priority={i === 0} />
            </button>
          ))}
        </div>
        <span className="glass absolute right-4 bottom-4 rounded-full px-3 py-1 text-xs font-semibold tabular-nums">
          {mobileIndex + 1} / {images.length}
        </span>
      </div>

      {/* Desktop: bento grid */}
      <div
        className={cn(
          "relative hidden gap-2 overflow-hidden rounded-3xl sm:grid sm:aspect-[2/1] lg:aspect-[21/9]",
          grid.length >= 5 ? "grid-cols-4 grid-rows-2" : grid.length >= 3 ? "grid-cols-3 grid-rows-2" : grid.length === 2 ? "grid-cols-2" : "grid-cols-1",
        )}
      >
        {grid.map((img, i) => (
          <button
            key={img.id}
            type="button"
            onClick={() => setLightbox(i)}
            aria-label={`Open photo ${i + 1}`}
            className={cn("group relative overflow-hidden bg-zinc-100 dark:bg-zinc-900", i === 0 && grid.length >= 3 && "col-span-2 row-span-2")}
          >
            <Image
              src={img.url}
              alt={img.alt || `${title} photo ${i + 1}`}
              fill
              sizes={i === 0 ? "(min-width: 1024px) 50vw, 66vw" : "25vw"}
              className="object-cover transition duration-700 ease-[var(--ease-out-expo)] group-hover:scale-[1.04]"
              priority={i === 0}
            />
            <span className="absolute inset-0 bg-black/0 transition group-hover:bg-black/10" />
          </button>
        ))}
        <button
          type="button"
          onClick={() => setLightbox(0)}
          className="glass absolute right-4 bottom-4 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold shadow-soft transition hover:shadow-float"
        >
          <Grid2x2 className="size-4" aria-hidden />
          Show all {images.length} photos
        </button>
      </div>

      <Lightbox images={images} index={lightbox} onIndex={setLightbox} title={title} />
    </>
  );
}

function Lightbox({ images, index, onIndex, title }: { images: GalleryImage[]; index: number | null; onIndex: (i: number | null) => void; title: string }) {
  const [direction, setDirection] = useState(1);
  const mounted = useSyncExternalStore(noopSubscribe, () => true, () => false);
  const open = index !== null;

  const go = useCallback(
    (delta: number) => {
      if (index === null) return;
      setDirection(delta);
      onIndex((index + delta + images.length) % images.length);
    },
    [index, images.length, onIndex],
  );

  useEffect(() => {
    if (!open) return;
    const { overflow } = document.body.style;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onIndex(null);
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = overflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, go, onIndex]);

  const onDragEnd = (_: unknown, info: PanInfo) => {
    if (info.offset.x < -80) go(1);
    else if (info.offset.x > 80) go(-1);
  };

  if (!mounted) return null;
  const current = index !== null ? images[index] : undefined;

  return createPortal(
    <AnimatePresence>
      {open && current && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`${title} photos`}
          className="fixed inset-0 z-[60] flex flex-col bg-zinc-950/95 text-white backdrop-blur-xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="flex items-center justify-between px-4 py-3 sm:px-6">
            <span className="text-sm font-medium tabular-nums text-white/80">
              {(index ?? 0) + 1} / {images.length}
            </span>
            <button type="button" onClick={() => onIndex(null)} className="grid size-10 place-items-center rounded-full transition hover:bg-white/10" aria-label="Close gallery">
              <X className="size-5" />
            </button>
          </div>

          <div className="relative flex-1 overflow-hidden">
            <AnimatePresence initial={false} custom={direction} mode="popLayout">
              <motion.div
                key={current.id}
                initial={{ x: direction * 80, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: direction * -80, opacity: 0 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.4}
                onDragEnd={onDragEnd}
                className="absolute inset-0 px-2 sm:px-20"
              >
                <Image src={current.url} alt={current.alt || title} fill sizes="100vw" className="pointer-events-none object-contain" priority />
              </motion.div>
            </AnimatePresence>

            {images.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => go(-1)}
                  className="absolute top-1/2 left-4 hidden size-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 backdrop-blur transition hover:bg-white/20 sm:grid"
                  aria-label="Previous photo"
                >
                  <ChevronLeft className="size-5" />
                </button>
                <button
                  type="button"
                  onClick={() => go(1)}
                  className="absolute top-1/2 right-4 hidden size-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 backdrop-blur transition hover:bg-white/20 sm:grid"
                  aria-label="Next photo"
                >
                  <ChevronRight className="size-5" />
                </button>
              </>
            )}
          </div>

          {current.alt && <p className="px-6 pt-3 text-center text-sm text-white/70">{current.alt}</p>}

          <div className="scrollbar-none flex justify-center gap-2 overflow-x-auto px-4 py-4">
            {images.map((img, i) => (
              <button
                key={img.id}
                type="button"
                onClick={() => {
                  setDirection(i > (index ?? 0) ? 1 : -1);
                  onIndex(i);
                }}
                className={cn("relative size-14 shrink-0 overflow-hidden rounded-lg transition", i === index ? "ring-2 ring-white" : "opacity-50 hover:opacity-100")}
                aria-label={`Photo ${i + 1}`}
                aria-current={i === index}
              >
                <Image src={img.url} alt="" fill sizes="56px" className="object-cover" />
              </button>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
