import Link from "next/link";
import { LayoutDashboard } from "lucide-react";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" className={`group inline-flex items-center gap-2 ${className}`} aria-label="InapDesa home">
      <span className="relative grid size-8 place-items-center overflow-hidden rounded-xl bg-ink text-white shadow-soft dark:bg-white dark:text-ink">
        <svg viewBox="0 0 24 24" className="size-[18px]" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
          <path d="M3 11.5 12 4l9 7.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6 10v9h12v-9" strokeLinejoin="round" />
          <path d="M10 19v-4.5a2 2 0 0 1 4 0V19" className="text-terracotta-400" stroke="currentColor" />
        </svg>
      </span>
      <span className="text-[17px] font-semibold tracking-tight">
        Inap<span className="text-brand-600">Desa</span>
      </span>
    </Link>
  );
}

export function SiteHeader() {
  return (
    <header className="glass sticky top-0 z-40 border-x-0 border-t-0 border-b-zinc-200/70 dark:border-b-zinc-800/80">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav className="flex items-center gap-1 text-sm font-medium">
          <Link href="/" className="hidden rounded-full px-4 py-2 text-zinc-600 transition hover:bg-zinc-100 hover:text-ink sm:inline-flex dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-white">
            Stays
          </Link>
          <Link
            href="/host"
            className="inline-flex items-center gap-2 rounded-full border border-zinc-200/80 px-4 py-2 text-zinc-700 transition hover:border-zinc-300 hover:shadow-soft dark:border-zinc-800/80 dark:text-zinc-300 dark:hover:border-zinc-700"
          >
            <LayoutDashboard className="size-4" aria-hidden />
            <span>Host</span>
          </Link>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-zinc-200/80 dark:border-zinc-800/80">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-10 text-sm text-zinc-500 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <Logo />
        <p>Book direct. Pay a secure deposit. Settle the rest on arrival.</p>
        <p>© {new Date().getFullYear()} InapDesa</p>
      </div>
    </footer>
  );
}
