"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Ban, Check, Copy, MessageCircle, MessageSquare } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { cancelBooking } from "@/app/host/actions";
import { smsLink, TEMPLATE_LABELS, whatsappLink, type MessageTemplate } from "@/lib/messaging";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { inputStyles } from "@/components/ui/field";

interface MessageActionsProps {
  phone: string;
  messages: Record<MessageTemplate, string>;
  suggested: MessageTemplate;
}

/** One-tap guest messaging: pick a template, open WhatsApp or SMS with the text pre-filled. */
export function MessageActions({ phone, messages, suggested }: MessageActionsProps) {
  const [template, setTemplate] = useState<MessageTemplate>(suggested);
  const [copied, setCopied] = useState(false);
  const text = messages[template];

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        aria-label="Message template"
        value={template}
        onChange={(e) => setTemplate(e.target.value as MessageTemplate)}
        className="h-9 rounded-xl border border-zinc-200/80 bg-white px-2.5 text-sm font-medium dark:border-zinc-800/80 dark:bg-zinc-900"
      >
        {(Object.keys(TEMPLATE_LABELS) as MessageTemplate[]).map((t) => (
          <option key={t} value={t}>
            {TEMPLATE_LABELS[t]}
          </option>
        ))}
      </select>
      <a
        href={whatsappLink(phone, text)}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex h-9 items-center gap-1.5 rounded-xl bg-[#25D366] px-3 text-sm font-semibold text-[#073e1f] transition hover:bg-[#1fbe5b]"
      >
        <MessageCircle className="size-4" aria-hidden /> WhatsApp
      </a>
      <a
        href={smsLink(phone, text)}
        className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-zinc-200/80 bg-white px-3 text-sm font-semibold transition hover:shadow-soft dark:border-zinc-800/80 dark:bg-zinc-900"
      >
        <MessageSquare className="size-4" aria-hidden /> SMS
      </a>
      <button
        type="button"
        onClick={copy}
        className="grid size-9 place-items-center rounded-xl border border-zinc-200/80 bg-white transition hover:shadow-soft dark:border-zinc-800/80 dark:bg-zinc-900"
        aria-label="Copy message"
        title="Copy message"
      >
        {copied ? <Check className="size-4 text-brand-600" /> : <Copy className="size-4" />}
      </button>
    </div>
  );
}

export function CancelBookingButton({ bookingId, reference, hasOnlinePayment }: { bookingId: string; reference: string; hasOnlinePayment: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [refund, setRefund] = useState(true);
  const [result, setResult] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const submit = () =>
    startTransition(async () => {
      const res = await cancelBooking(bookingId, reason, hasOnlinePayment && refund);
      setResult(res.message ?? null);
      if (res.ok) {
        setOpen(false);
        router.refresh();
      }
    });

  return (
    <div className="w-full">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex h-9 items-center gap-1.5 rounded-xl px-3 text-sm font-semibold text-red-600 transition hover:bg-red-50 dark:hover:bg-red-500/10"
      >
        <Ban className="size-4" aria-hidden /> Cancel booking
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
            <div className="mt-3 space-y-3 rounded-2xl border border-red-200 bg-red-50/60 p-4 dark:border-red-500/20 dark:bg-red-500/5">
              <p className="text-sm font-semibold">Cancel booking {reference}?</p>
              <textarea
                className={cn(inputStyles, "resize-none text-sm")}
                rows={2}
                placeholder="Reason (shown to the guest on their booking page)"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                maxLength={500}
              />
              {hasOnlinePayment && (
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={refund} onChange={(e) => setRefund(e.target.checked)} className="size-4 accent-brand-600" />
                  Refund the online payment via Stripe
                </label>
              )}
              <div className="flex gap-2">
                <Button variant="danger" size="sm" onClick={submit} loading={pending}>
                  Confirm cancellation
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
                  Keep booking
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {result && !open && (
        <p role="status" className="mt-2 text-xs text-zinc-500">
          {result}
        </p>
      )}
    </div>
  );
}
