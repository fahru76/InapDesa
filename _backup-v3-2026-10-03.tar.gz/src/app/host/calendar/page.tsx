import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AvailabilityManager } from "@/components/host/availability-manager";
import { addDays, todayInTimeZone } from "@/lib/dates";
import { getHostContext } from "@/lib/host";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Calendar" };

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function HostCalendarPage({ searchParams }: Props) {
  const sp = await searchParams;
  const { supabase, property } = await getHostContext(typeof sp.property === "string" ? sp.property : undefined);
  if (!property) redirect("/host/settings");

  const today = todayInTimeZone(property.timezone);
  const horizon = addDays(today, 550);
  const nowIso = new Date().toISOString();

  const [bookingsRes, blockedRes] = await Promise.all([
    supabase
      .from("bookings")
      .select("id, reference, guest_name, check_in, check_out, status, hold_expires_at")
      .eq("property_id", property.id)
      .in("status", ["pending_payment", "confirmed", "paid_in_full", "checked_in", "completed"])
      .gte("check_out", today)
      .lte("check_in", horizon),
    supabase.from("blocked_dates").select("date, reason").eq("property_id", property.id).gte("date", today).lte("date", horizon),
  ]);
  if (bookingsRes.error) throw new Error(bookingsRes.error.message);
  if (blockedRes.error) throw new Error(blockedRes.error.message);

  const bookings = (bookingsRes.data ?? [])
    .filter((b) => b.status !== "pending_payment" || (b.hold_expires_at !== null && b.hold_expires_at > nowIso))
    .map((b) => ({ id: b.id, reference: b.reference, guest_name: b.guest_name, check_in: b.check_in, check_out: b.check_out, status: b.status }));

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-medium text-zinc-500">{property.title}</p>
        <h1 className="text-3xl font-semibold tracking-tight">Availability</h1>
        <p className="mt-1 text-sm text-zinc-500">Close nights for owner stays, maintenance or off-platform bookings. Guests see changes instantly.</p>
      </header>
      <AvailabilityManager
        propertyId={property.id}
        today={today}
        bookings={bookings}
        blocked={blockedRes.data ?? []}
        rates={{ weekday: property.weekday_rate, weekend: property.weekend_rate, weekendDays: property.weekend_days, currency: property.currency }}
      />
    </div>
  );
}
