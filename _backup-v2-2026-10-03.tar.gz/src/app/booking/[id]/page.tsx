import { CalendarDays, CircleAlert, CircleCheck, Clock, Hourglass, MapPin, MessageCircle, Users, XCircle } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PriceBreakdown } from "@/components/booking/price-breakdown";
import { PaymentStatusPoller, QrPass, ReceiptActions } from "@/components/receipt/receipt-client";
import { buttonStyles } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { ContentSections } from "@/components/property/content-sections";
import { getGuestBooking, getGuestOnlySections, syncPendingBooking, type BookingWithProperty } from "@/lib/booking-service";
import { accentCss, localizeProperty, parseSections } from "@/lib/content";
import { formatDateLong, formatTime } from "@/lib/dates";
import { publicEnv } from "@/lib/env";
import type { T } from "@/lib/i18n";
import { getT } from "@/lib/i18n-server";
import { whatsappLink } from "@/lib/messaging";
import { formatMoney, guestSummary, quoteFromSnapshot } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export async function generateMetadata(): Promise<Metadata> {
  const t = await getT();
  return { title: t("rc.metaTitle"), robots: { index: false, follow: false } };
}

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";
const PAID = new Set(["confirmed", "paid_in_full", "checked_in", "completed"]);

export default async function BookingReceiptPage({ params, searchParams }: Props) {
  const [{ id }, sp, t] = await Promise.all([params, searchParams, getT()]);
  const token = one(sp.token);
  let booking = await getGuestBooking(id, token);
  if (!booking) notFound();

  // The webhook may not have arrived yet — reconcile directly with Stripe.
  if (booking.status === "pending_payment" || booking.status === "expired") {
    await syncPendingBooking(booking);
    booking = (await getGuestBooking(id, token)) ?? booking;
  }

  const redirectFailed = one(sp.redirect_status) === "failed";

  const accent = <style>{`:root{${accentCss(booking.property.accent_color)}}`}</style>;
  if (PAID.has(booking.status)) {
    const guestSections = parseSections(await getGuestOnlySections(booking.property_id));
    return (
      <>
        {accent}
        <Confirmed booking={booking} t={t} guestSections={guestSections} />
      </>
    );
  }
  return (
    <>
      {accent}
      {booking.status === "pending_payment" && !redirectFailed ? <Processing booking={booking} t={t} /> : <NotCompleted booking={booking} failed={redirectFailed} t={t} />}
    </>
  );
}

function Confirmed({ booking, t, guestSections }: { booking: BookingWithProperty; t: T; guestSections: ReturnType<typeof parseSections> }) {
  const p = booking.property;
  const locale = t.locale;
  const text = localizeProperty(p, locale);
  const quote = quoteFromSnapshot(booking);
  const outstanding = Math.max(0, booking.total_amount - booking.amount_paid);
  const location = [p.address_line, p.city, p.region].filter(Boolean).join(", ");
  const passUrl = `${publicEnv.siteUrl}/host/check-in/${booking.reference}`;

  return (
    <div className="surface-muted min-h-[calc(100dvh-4rem)]">
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:py-14">
        <div className="text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-full bg-brand-600 text-white shadow-[0_12px_32px_-8px_rgb(5_150_105/0.6)]">
            <CircleCheck className="size-7" aria-hidden />
          </div>
          <h1 className="mt-5 text-3xl font-semibold tracking-tight text-balance">{t("rc.goingTo", { city: p.city })}</h1>
          <p className="mx-auto mt-2 max-w-xl text-zinc-600 dark:text-zinc-400">
            {booking.status === "paid_in_full" ? t("rc.fullyPaid") : t("rc.depositIn")} {t("rc.savePage")}
          </p>
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl border border-zinc-200/80 bg-white shadow-float dark:border-zinc-800/80 dark:bg-zinc-900">
          <div className="grid md:grid-cols-[1fr_280px]">
            <div className="p-6 sm:p-8">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{t("rc.booking", { ref: booking.reference })}</p>
                  <h2 className="mt-1 text-xl font-semibold tracking-tight">{text.title}</h2>
                </div>
                <StatusBadge status={booking.status} label={t(`status.${booking.status}`)} />
              </div>

              <dl className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
                <Detail icon={CalendarDays} label={t("rc.checkIn")} value={formatDateLong(booking.check_in, locale)} sub={t("rc.from", { time: formatTime(p.check_in_time, locale) })} />
                <Detail icon={CalendarDays} label={t("rc.checkOut")} value={formatDateLong(booking.check_out, locale)} sub={t("rc.by", { time: formatTime(p.check_out_time, locale) })} />
                <Detail icon={Users} label={t("rc.guests")} value={guestSummary(booking, locale)} sub={`${booking.guest_name} · ${booking.guest_email}`} />
                <Detail icon={MapPin} label={t("rc.address")} value={location || p.city} sub={p.country} />
              </dl>

              <div className="mt-6 grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl bg-brand-50 p-4 dark:bg-brand-500/10">
                  <p className="text-xs font-semibold uppercase tracking-wider text-brand-700 dark:text-brand-300">{t("rc.paid")}</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight tabular-nums">{formatMoney(booking.amount_paid, booking.currency)}</p>
                </div>
                <div className="rounded-2xl bg-zinc-100 p-4 dark:bg-zinc-800/60">
                  <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{t("rc.dueCheckIn")}</p>
                  <p className="mt-1 text-2xl font-bold tracking-tight tabular-nums">{formatMoney(outstanding, booking.currency)}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center border-t border-dashed border-zinc-300 bg-gradient-to-b from-zinc-50 to-white p-8 md:border-t-0 md:border-l dark:border-zinc-700 dark:from-zinc-900 dark:to-zinc-950">
              <QrPass value={passUrl} reference={booking.reference} />
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
          <ReceiptActions
            title={text.title}
            reference={booking.reference}
            checkIn={booking.check_in}
            checkOut={booking.check_out}
            checkInTime={p.check_in_time}
            checkOutTime={p.check_out_time}
            location={location || p.city}
            timeZone={p.timezone}
          />
          {p.host_phone && (
            <a
              href={whatsappLink(p.host_phone, `Hi${p.host_display_name ? ` ${p.host_display_name}` : ""}! I've booked ${p.title} (${booking.reference}).`)}
              target="_blank"
              rel="noopener noreferrer"
              className={buttonStyles({ variant: "whatsapp", size: "sm", className: "no-print" })}
            >
              <MessageCircle className="size-4" aria-hidden /> {t("rc.messageHost", { name: p.host_display_name ?? "host" })}
            </a>
          )}
        </div>

        {guestSections.some((s) => s.visible) && (
          <section className="card mt-8 p-6 sm:p-8">
            <p className="text-xs font-semibold tracking-wider text-brand-700 uppercase dark:text-brand-300">{t("rc.forYourStay")}</p>
            <p className="mt-1 text-xs text-zinc-500">{t("rc.forYourStay.hint")}</p>
            <ContentSections sections={guestSections} locale={locale} variant="receipt" />
          </section>
        )}

        <section className="card mt-8 p-6 sm:p-8">
          <h2 className="mb-4 text-lg font-semibold tracking-tight">{t("rc.priceDetails")}</h2>
          <PriceBreakdown quote={quote} hideSplit locale={locale} />
          <p className="mt-4 text-xs leading-5 text-zinc-500">{text.cancellation_policy}</p>
        </section>
      </div>
    </div>
  );
}

function Processing({ booking, t }: { booking: BookingWithProperty; t: T }) {
  return (
    <StateCard
      icon={Hourglass}
      tone="neutral"
      title={t("rc.almost")}
      body={t("rc.confirming", { amount: formatMoney(booking.amount_due_now, booking.currency), title: localizeProperty(booking.property, t.locale).title })}
    >
      <PaymentStatusPoller />
    </StateCard>
  );
}

function NotCompleted({ booking, failed, t }: { booking: BookingWithProperty; failed: boolean; t: T }) {
  const rebook = `/stays/${booking.property.slug}?${new URLSearchParams({
    checkIn: booking.check_in,
    checkOut: booking.check_out,
    adults: String(booking.adults),
    children: String(booking.children),
    infants: String(booking.infants),
  })}`;

  if (booking.status === "cancelled") {
    const conflict = booking.cancellation_reason === "payment_after_hold_conflict";
    return (
      <StateCard
        icon={XCircle}
        tone="danger"
        title={t("rc.cancelled")}
        body={
          conflict
            ? t("rc.cancelled.conflict")
            : (booking.cancellation_reason ?? t("rc.cancelled.contact"))
        }
      >
        <Link href={`/stays/${booking.property.slug}`} className={buttonStyles({ className: "mt-6" })}>
          {t("rc.findOther")}
        </Link>
      </StateCard>
    );
  }

  return (
    <StateCard
      icon={failed ? CircleAlert : Clock}
      tone="warning"
      title={failed ? t("rc.failed") : t("rc.expired")}
      body={failed ? t("rc.failed.body") : t("rc.expired.body")}
    >
      <Link href={rebook} className={buttonStyles({ className: "mt-6" })}>
        {failed ? t("rc.tryAgain") : t("rc.checkAvailability")}
      </Link>
    </StateCard>
  );
}

function StateCard({
  icon: Icon,
  tone,
  title,
  body,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  tone: "neutral" | "warning" | "danger";
  title: string;
  body: string;
  children?: React.ReactNode;
}) {
  const toneClass = {
    neutral: "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
    warning: "bg-terracotta-500/10 text-terracotta-600",
    danger: "bg-red-50 text-red-600 dark:bg-red-500/10",
  }[tone];
  return (
    <div className="mx-auto max-w-lg px-4 py-20 text-center">
      <div className={`mx-auto grid size-14 place-items-center rounded-full ${toneClass}`}>
        <Icon className="size-7" />
      </div>
      <h1 className="mt-5 text-2xl font-semibold tracking-tight">{title}</h1>
      <p className="mt-2 text-zinc-600 dark:text-zinc-400">{body}</p>
      {children}
    </div>
  );
}

function Detail({ icon: Icon, label, value, sub }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; sub?: string | null }) {
  return (
    <div className="flex gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-zinc-400" />
      <div className="min-w-0">
        <dt className="text-xs font-semibold uppercase tracking-wider text-zinc-500">{label}</dt>
        <dd className="mt-0.5 font-medium">{value}</dd>
        {sub && <dd className="break-words text-zinc-500">{sub}</dd>}
      </div>
    </div>
  );
}
