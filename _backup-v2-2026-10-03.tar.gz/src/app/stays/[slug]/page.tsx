import { Bath, BedDouble, Clock, DoorOpen, ExternalLink, MapPin, ShieldCheck, Users } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { BookingProvider } from "@/components/booking/booking-context";
import { BookingPanel } from "@/components/booking/booking-panel";
import { AvailabilitySection, MobileBookingBar } from "@/components/booking/booking-sections";
import { ContentSections } from "@/components/property/content-sections";
import { Gallery } from "@/components/property/gallery";
import { AmenityList, ExpandableText, HostCard } from "@/components/property/property-sections";
import { accentCss, isHeroLayout, localizeProperty, parseSections } from "@/lib/content";
import { addDays, formatTime } from "@/lib/dates";
import { getT } from "@/lib/i18n-server";
import { whatsappLink } from "@/lib/messaging";
import { formatMoney } from "@/lib/pricing";
import { getAvailability, getPropertyBySlug } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const int = (v: string | string[] | undefined) => {
  const raw = one(v);
  if (raw === undefined) return undefined;
  const n = Number(raw);
  return Number.isInteger(n) ? n : undefined;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const [property, t] = await Promise.all([getPropertyBySlug(slug), getT()]);
  if (!property) return { title: "Stay not found" };
  const text = localizeProperty(property, t.locale);
  return {
    title: text.title,
    description: text.tagline ?? text.description.slice(0, 160),
    openGraph: { images: property.images[0] ? [{ url: property.images[0].url }] : undefined },
  };
}

export default async function StayPage({ params, searchParams }: Props) {
  const [{ slug }, sp, t] = await Promise.all([params, searchParams, getT()]);
  const property = await getPropertyBySlug(slug);
  if (!property || !property.is_published) notFound();

  const locale = t.locale;
  const text = localizeProperty(property, locale);
  const sections = parseSections(property.sections);
  const layout = isHeroLayout(property.hero_layout) ? property.hero_layout : "mosaic";
  const availability = await getAvailability(property);
  const location = [property.city, property.region, property.country].filter(Boolean).join(", ");
  const mapsHref =
    property.latitude !== null && property.longitude !== null
      ? `https://www.google.com/maps/search/?api=1&query=${property.latitude},${property.longitude}`
      : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
  const baths = Number(property.bathrooms);

  return (
    <BookingProvider
      property={property}
      today={availability.from}
      maxDate={addDays(availability.to, -1)}
      booked={availability.booked}
      blocked={availability.blocked}
      initial={{ checkIn: one(sp.checkIn), checkOut: one(sp.checkOut), adults: int(sp.adults), children: int(sp.children), infants: int(sp.infants) }}
    >
      {/* Owner's accent colour re-themes every brand-* token (including portals such as the bottom sheet). */}
      <style>{`:root{${accentCss(property.accent_color)}}`}</style>

      <div className="mx-auto max-w-7xl px-4 pt-6 pb-32 sm:px-6 lg:px-8 lg:pb-16">
        {layout === "mosaic" && (
          <header className="mb-6 flex items-start gap-4">
            {property.logo_url && (
              <div className="relative size-12 shrink-0 overflow-hidden rounded-xl bg-white ring-1 ring-zinc-200/80 sm:size-14 dark:ring-zinc-800">
                <Image src={property.logo_url} alt="" fill sizes="56px" className="object-contain p-1.5" />
              </div>
            )}
            <div className="min-w-0">
              <h1 className="text-2xl font-semibold tracking-tight text-balance sm:text-3xl lg:text-[2.1rem]">{text.title}</h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-zinc-600 dark:text-zinc-400">
                <a href={mapsHref} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-medium underline-offset-4 hover:underline">
                  <MapPin className="size-4" aria-hidden />
                  {location}
                </a>
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="size-4 text-brand-600" aria-hidden />
                  {t("stay.bookDirect")}
                </span>
              </div>
            </div>
          </header>
        )}

        <Gallery
          images={property.images.map((i) => ({ id: i.id, url: i.url, alt: i.alt }))}
          title={text.title}
          layout={layout}
          hero={{ tagline: text.tagline, location, logoUrl: property.logo_url }}
        />

        <div className="mt-10 grid gap-12 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-16">
          <div className="min-w-0">
            {layout === "mosaic" && text.tagline && <p className="text-lg font-medium tracking-tight text-zinc-800 dark:text-zinc-200">{text.tagline}</p>}

            <ul className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Fact icon={Users} label={t("stay.guests", { n: property.max_guests })} />
              <Fact icon={DoorOpen} label={t.plural("stay.bedrooms", property.bedrooms)} />
              <Fact icon={BedDouble} label={t.plural("stay.beds", property.beds)} />
              <Fact icon={Bath} label={t.plural("stay.baths", baths)} />
            </ul>

            <Section title={t("stay.about")} first>
              <ExpandableText text={text.description} />
            </Section>

            <ContentSections sections={sections.filter((s) => s.audience === "public")} locale={locale} />

            {property.amenities.length > 0 && (
              <Section title={t("stay.offers")}>
                <AmenityList amenities={property.amenities} />
              </Section>
            )}

            <AvailabilitySection />

            <Section title={t("stay.goodToKnow")}>
              <div className="grid gap-6 sm:grid-cols-2">
                <div className="card p-5">
                  <h3 className="flex items-center gap-2 font-semibold">
                    <Clock className="size-4 text-brand-600" aria-hidden /> {t("stay.arrival")}
                  </h3>
                  <dl className="mt-3 space-y-1.5 text-sm text-zinc-600 dark:text-zinc-400">
                    <div className="flex justify-between gap-3">
                      <dt>{t("stay.checkIn")}</dt>
                      <dd className="font-medium text-ink dark:text-white">{t("stay.from", { time: formatTime(property.check_in_time, locale) })}</dd>
                    </div>
                    <div className="flex justify-between gap-3">
                      <dt>{t("stay.checkOut")}</dt>
                      <dd className="font-medium text-ink dark:text-white">{t("stay.by", { time: formatTime(property.check_out_time, locale) })}</dd>
                    </div>
                    <div className="flex justify-between gap-3">
                      <dt>{t("stay.minStay")}</dt>
                      <dd className="font-medium text-ink dark:text-white">{t.plural("stay.nights", property.min_nights)}</dd>
                    </div>
                  </dl>
                </div>
                <div className="card p-5">
                  <h3 className="flex items-center gap-2 font-semibold">
                    <ShieldCheck className="size-4 text-brand-600" aria-hidden /> {t("stay.paymentPolicy")}
                  </h3>
                  <p className="mt-3 text-sm leading-6 text-zinc-600 dark:text-zinc-400">
                    {property.payment_policy === "full" ? t("stay.policy.full") : t("stay.policy.deposit", { pct: property.deposit_percent })}
                    {property.security_deposit > 0 && ` ${t("stay.policy.security", { amount: formatMoney(property.security_deposit, property.currency) })}`}
                  </p>
                  <p className="mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{text.cancellation_policy}</p>
                </div>
              </div>
              {text.house_rules.length > 0 && (
                <ul className="mt-6 grid gap-2 text-sm text-zinc-700 sm:grid-cols-2 dark:text-zinc-300">
                  {text.house_rules.map((rule) => (
                    <li key={rule} className="flex items-start gap-2">
                      <span className="mt-2 size-1.5 shrink-0 rounded-full bg-terracotta-500" aria-hidden />
                      {rule}
                    </li>
                  ))}
                </ul>
              )}
            </Section>

            <Section title={t("stay.where")}>
              <div className="card flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-center">
                <div>
                  <p className="font-semibold">{location}</p>
                  <p className="mt-1 text-sm text-zinc-500">{t("stay.addressAfter")}</p>
                </div>
                <a
                  href={mapsHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 self-start rounded-xl border border-zinc-200/80 px-3.5 py-2 text-sm font-semibold transition hover:shadow-soft sm:self-auto dark:border-zinc-800/80"
                >
                  {t("stay.openMaps")} <ExternalLink className="size-3.5" aria-hidden />
                </a>
              </div>
            </Section>

            {property.host_display_name && (
              <Section title={t("stay.meetHost")}>
                <HostCard
                  name={property.host_display_name}
                  bio={text.host_bio}
                  avatarUrl={property.host_avatar_url}
                  languages={property.host_languages}
                  hostSince={property.host_since}
                  whatsappHref={property.host_phone ? whatsappLink(property.host_phone, `Hi! I'm interested in staying at ${text.title}.`) : null}
                />
              </Section>
            )}
          </div>

          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <BookingPanel />
            </div>
          </aside>
        </div>
      </div>

      <MobileBookingBar />
    </BookingProvider>
  );
}

function Section({ title, first, children }: { title: string; first?: boolean; children: React.ReactNode }) {
  return (
    <section className={`border-t border-zinc-200/80 py-10 dark:border-zinc-800/80 ${first ? "mt-8" : ""}`}>
      <h2 className="mb-5 text-xl font-semibold tracking-tight">{title}</h2>
      {children}
    </section>
  );
}

function Fact({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  return (
    <li className="surface-muted flex items-center gap-2.5 rounded-2xl px-4 py-3 text-sm font-medium">
      <Icon className="size-4 text-zinc-500" />
      {label}
    </li>
  );
}
