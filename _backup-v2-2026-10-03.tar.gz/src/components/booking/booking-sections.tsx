"use client";

import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { useCallback, useState } from "react";
import { formatRange } from "@/lib/dates";
import { formatMoney } from "@/lib/pricing";
import { BottomSheet } from "@/components/ui/bottom-sheet";
import { useT } from "@/components/i18n/locale";
import { buttonStyles } from "@/components/ui/button";
import { useBooking } from "./booking-context";
import { BookingPanel } from "./booking-panel";
import { DateRangeCalendar } from "./date-range-calendar";

/** Sticky bottom bar on mobile; opens the booking flow in a bottom sheet. */
export function MobileBookingBar() {
  const b = useBooking();
  const t = useT();
  const [open, setOpen] = useState(false);
  const close = useCallback(() => setOpen(false), []);

  return (
    <>
      <div className="glass pb-safe fixed inset-x-0 bottom-0 z-30 border-x-0 border-b-0 px-4 pt-3 lg:hidden">
        <div className="mx-auto flex max-w-xl items-center justify-between gap-4">
          <button type="button" onClick={() => setOpen(true)} className="text-left">
            {b.quote ? (
              <>
                <p className="text-[15px] font-semibold">
                  {formatMoney(b.quote.dueNow, b.property.currency)} <span className="font-normal text-zinc-500">{t("mobile.dueToday")}</span>
                </p>
                <p className="text-xs font-medium text-zinc-600 underline underline-offset-2 dark:text-zinc-400">
                  {b.range.checkIn && b.range.checkOut && formatRange(b.range.checkIn, b.range.checkOut, t.locale)} · {t.plural("stay.nights", b.quote.nights)}
                </p>
              </>
            ) : (
              <>
                <p className="text-[15px] font-semibold">
                  {formatMoney(b.fromPrice, b.property.currency)} <span className="font-normal text-zinc-500">{t("panel.perNight")}</span>
                </p>
                <p className="text-xs font-medium text-zinc-600 underline underline-offset-2 dark:text-zinc-400">{t("mobile.addDates")}</p>
              </>
            )}
          </button>
          {b.checkoutHref ? (
            <Link href={b.checkoutHref} className={buttonStyles({ className: "px-6" })}>
              {t("mobile.reserve")}
            </Link>
          ) : (
            <button type="button" onClick={() => setOpen(true)} className={buttonStyles({ className: "px-6" })}>
              {t("mobile.checkDates")}
            </button>
          )}
        </div>
      </div>

      <BottomSheet
        open={open}
        onClose={close}
        title={b.quote ? t.plural("stay.nights", b.quote.nights) : t("mobile.selectDates")}
        footer={
          b.checkoutHref ? (
            <Link href={b.checkoutHref} className={buttonStyles({ size: "lg", className: "w-full" })}>
              {t("mobile.reserveToday", { amount: formatMoney(b.quote?.dueNow ?? 0, b.property.currency) })}
              <ArrowRight className="size-4" aria-hidden />
            </Link>
          ) : (
            <button type="button" disabled className={buttonStyles({ size: "lg", className: "w-full" })}>
              {b.range.checkIn ? t("mobile.selectCheckOut") : t("mobile.selectCheckIn")}
            </button>
          )
        }
      >
        <BookingPanel variant="sheet" />
      </BottomSheet>
    </>
  );
}

/** Large in-page availability calendar (two months on desktop). */
export function AvailabilitySection() {
  const b = useBooking();
  const t = useT();
  return (
    <section aria-labelledby="availability-heading" className="border-t border-zinc-200/80 py-10 dark:border-zinc-800/80">
      <h2 id="availability-heading" className="text-xl font-semibold tracking-tight">
        {b.quote ? t("avail.selected", { n: b.quote.nights }) : t("avail.title")}
      </h2>
      <p className="mt-1 text-sm text-zinc-500">
        {b.range.checkIn && b.range.checkOut
          ? formatRange(b.range.checkIn, b.range.checkOut, t.locale)
          : t("avail.rates", { weekend: formatMoney(b.property.weekend_rate, b.property.currency), weekday: formatMoney(b.property.weekday_rate, b.property.currency) })}
      </p>
      <DateRangeCalendar
        className="mt-6"
        months={2}
        checkIn={b.range.checkIn}
        checkOut={b.range.checkOut}
        onChange={b.setRange}
        today={b.today}
        maxDate={b.maxDate}
        unavailable={b.unavailable}
        blocked={b.blocked}
        minNights={b.property.min_nights}
        maxNights={b.property.max_nights}
        priceFor={b.priceFor}
      />
    </section>
  );
}
