import { ChevronDown, MapPin } from "lucide-react";
import { loc, sectionIcon, type ContentSection, type Locale } from "@/lib/content";
import { cn } from "@/lib/utils";

/**
 * Renders owner-defined sections. Pure presentational (no hooks), so it works in
 * Server Components, the receipt page and the editor's client-side live preview.
 */
export function ContentSections({
  sections,
  locale,
  variant = "page",
  className,
}: {
  sections: ContentSection[];
  locale: Locale;
  variant?: "page" | "receipt" | "preview";
  className?: string;
}) {
  const visible = sections.filter((s) => s.visible && (s.items.some((i) => i.title.en.trim()) || (s.body && s.body.en.trim())));
  if (visible.length === 0) return null;
  return (
    <div className={className}>
      {visible.map((s) => (
        <section
          key={s.id}
          aria-labelledby={`sec-${s.id}`}
          className={cn(variant === "page" ? "border-t border-zinc-200/80 py-10 dark:border-zinc-800/80" : "py-6")}
        >
          <h2 id={`sec-${s.id}`} className={cn("mb-5 font-semibold tracking-tight", variant === "preview" ? "text-lg" : "text-xl")}>
            {loc(s.title, locale)}
          </h2>
          <SectionBody section={s} locale={locale} compact={variant === "preview"} />
        </section>
      ))}
    </div>
  );
}

function SectionBody({ section: s, locale, compact }: { section: ContentSection; locale: Locale; compact: boolean }) {
  const items = s.items.filter((i) => i.title.en.trim());
  switch (s.type) {
    case "highlights":
      return (
        <ul className={cn("grid gap-4", compact ? "grid-cols-1" : "sm:grid-cols-2")}>
          {items.map((it) => {
            const Icon = sectionIcon(it.icon);
            return (
              <li key={it.id} className="flex gap-4">
                <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-brand-50 text-brand-700 dark:bg-brand-500/10 dark:text-brand-300">
                  <Icon className="size-5" aria-hidden />
                </span>
                <div>
                  <p className="font-semibold">{loc(it.title, locale)}</p>
                  {it.text.en.trim() && <p className="mt-0.5 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{loc(it.text, locale)}</p>}
                </div>
              </li>
            );
          })}
        </ul>
      );

    case "experiences":
      return (
        <ul className={cn("grid gap-3", compact ? "grid-cols-1" : "sm:grid-cols-2")}>
          {items.map((it) => (
            <li key={it.id} className="card flex flex-col p-4">
              <div className="flex items-start justify-between gap-3">
                <p className="font-semibold">{loc(it.title, locale)}</p>
                {it.meta && it.meta.en.trim() && (
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-zinc-100 px-2.5 py-0.5 text-xs font-medium text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
                    <MapPin className="size-3" aria-hidden />
                    {loc(it.meta, locale)}
                  </span>
                )}
              </div>
              {it.text.en.trim() && <p className="mt-1.5 text-sm leading-6 text-zinc-600 dark:text-zinc-400">{loc(it.text, locale)}</p>}
            </li>
          ))}
        </ul>
      );

    case "faq":
      return (
        <div className="divide-y divide-zinc-200/80 rounded-2xl border border-zinc-200/80 dark:divide-zinc-800/80 dark:border-zinc-800/80">
          {items.map((it) => (
            <details key={it.id} className="group px-5 [&_summary::-webkit-details-marker]:hidden">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 font-semibold">
                {loc(it.title, locale)}
                <ChevronDown className="size-4 shrink-0 text-zinc-400 transition-transform group-open:rotate-180" aria-hidden />
              </summary>
              <p className="pb-4 text-[15px] leading-7 whitespace-pre-line text-zinc-600 dark:text-zinc-400">{loc(it.text, locale)}</p>
            </details>
          ))}
        </div>
      );

    case "house_guide":
      return (
        <dl className={cn("grid gap-3", !compact && "sm:grid-cols-2")}>
          {items.map((it) => (
            <div key={it.id} className="rounded-2xl bg-zinc-50 p-4 dark:bg-zinc-800/60">
              <dt className="text-xs font-semibold tracking-wider text-zinc-500 uppercase">{loc(it.title, locale)}</dt>
              <dd className="mt-1 text-[15px] font-medium break-words whitespace-pre-line">{loc(it.text, locale)}</dd>
            </div>
          ))}
        </dl>
      );

    case "text":
      return <p className="text-[15px] leading-7 whitespace-pre-line text-zinc-700 dark:text-zinc-300">{loc(s.body, locale)}</p>;
  }
}
